//
//  IPSHomeController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 25/11/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSPlannedActionController.h"
#import "IPSProblemController.h"
#import "IPSVideoController.h"
#import "IPSMoodController.h"
#import "IPSHomeController.h"



@interface IPSHomeController () <UITableViewDataSource, UITableViewDelegate>

@end


@implementation IPSHomeController

#pragma mark - Initialization

- (id)init {
    self = [super init];
    if (self) {
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = YES;
    }
    
    SET_BACKGROUND(self.view, self.view.bounds);
    self.navigationController.navigationBarHidden = YES;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGFloat aYOffset = ((SCREEN_HEIGHT / 2) - ((55 * 3) / 2) + 20);
    
    UITableView *aTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, aYOffset, 320, (55 * 3))];
    [aTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [aTableView setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:aTableView];
    [aTableView setDataSource:self];
    [aTableView setDelegate:self];
    [aTableView setBounces:NO];
    
    UIButton *aYoutubeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [aYoutubeButton titleLabel].font = HELVETICA_NEUE(15);
    [aYoutubeButton setImage:IMAGE(@"Youtube") forState:UIControlStateNormal];
    [aYoutubeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [aYoutubeButton setFrame:CGRectMake(20, (self.view.bounds.size.height - 23 - 15), 200, 23)];
    [aYoutubeButton setTitle:NSLocalizedString(@"VideoTutorial", @"") forState:UIControlStateNormal];
    [aYoutubeButton addTarget:self action:@selector(showYoutubeVideo) forControlEvents:UIControlEventTouchUpInside];
    [[self view] addSubview:aYoutubeButton];
    
    
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    NSCalendar *aCalendar = [NSCalendar currentCalendar];
    NSDate *aTomorrow = [aCalendar dateByAddingUnit:NSCalendarUnitDay value:1 toDate:[NSDate date] options:0];
    
    NSDateComponents *aNextDayComponents = [aCalendar components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit) fromDate:aTomorrow];
    [aNextDayComponents setSecond:0];
    [aNextDayComponents setMinute:0];
    [aNextDayComponents setHour:11];
    
    NSDate *aDate = [aCalendar dateFromComponents:aNextDayComponents];
    
    UILocalNotification *aLocalNotification = [[UILocalNotification alloc] init];
    aLocalNotification.alertBody = NSLocalizedString(@"LocalNotification", @"");
    aLocalNotification.soundName = UILocalNotificationDefaultSoundName;
    aLocalNotification.repeatInterval = NSCalendarUnitDay;
    aLocalNotification.applicationIconBadgeNumber = 1;
    aLocalNotification.fireDate = aDate;
    
    [[UIApplication sharedApplication] scheduleLocalNotification:aLocalNotification];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}


- (void)viewWillAppear:(BOOL)iAnimated {
    [super viewWillAppear:iAnimated];
    self.navigationController.navigationBarHidden = YES;
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 1;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = 3;
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.textColor = [UIColor whiteColor];
        aCell.backgroundColor = [UIColor clearColor];
        
        NSString *aLocalizedLanguage = @"";
        NSArray *localizations = [[NSBundle mainBundle] preferredLocalizations];
        for (aLocalizedLanguage in localizations) {
            if ([aLocalizedLanguage isEqualToString:@"en"] ) {
                aCell.textLabel.font = FONT(@"HelveticaNeue-CondensedBold", 30);
                aCell.textLabel.adjustsFontSizeToFitWidth = YES;
            }else if ([aLocalizedLanguage isEqualToString:@"es"]){
                aCell.textLabel.font = FONT(@"HelveticaNeue-CondensedBold", 20);
            }
        }
        
        if (theRow == 0) {
            aCell.imageView.image = IMAGE(@"ProblemSolve");
            aCell.backgroundColor = RGBA_COLOR(253, 177, 126, 1);
            aCell.textLabel.text = NSLocalizedString(@"ProblemSolving", @"");
        } else if (theRow == 1) {
            aCell.imageView.image = IMAGE(@"ActionPlan");
            aCell.backgroundColor = RGBA_COLOR(229, 149, 165, 1);
            aCell.textLabel.text = NSLocalizedString(@"ActionPlan", @"");
        } else if (theRow == 2) {
            aCell.imageView.image = IMAGE(@"MoodChart");
            aCell.backgroundColor = RGBA_COLOR(136, 151, 195, 1);
            aCell.textLabel.text = NSLocalizedString(@"MoodChart", @"");
        }
    }
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    if (iIndexPath.row == 0) {
        [self showProblem];
    } else if (iIndexPath.row == 1) {
        [self showActionPlan];
    } else if (iIndexPath.row == 2) {
        [self showMoodChart];
    }
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 55;
    return aHeight;
}


#pragma mark - Private

- (void)showProblem {
    IPSProblemController *aProblemController = [[IPSProblemController alloc] init];
    [self.navigationController pushViewController:aProblemController animated:YES];
}


- (void)showActionPlan {
    if ([[Session actionPlans] count] > 0) {
        IPSPlannedActionController *aPlannedActionController = [[IPSPlannedActionController alloc] init];
        [self.navigationController pushViewController:aPlannedActionController animated:YES];
    } else {
        [[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Sorry!", @"") message:NSLocalizedString(@"NoActionPlanMsg", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil] show];
    }
}


- (void)showMoodChart {
    IPSMoodController *aMoodController = [[IPSMoodController alloc] init];
    [self.navigationController presentViewController:aMoodController animated:YES completion:nil];
}


- (void)showYoutubeVideo {
    IPSVideoController *aYoutubeController = [[IPSVideoController alloc] init];
    [self.navigationController presentViewController:aYoutubeController animated:YES completion:nil];
}


#pragma mark - Orientation Method

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)iInterfaceOrientation {
    return (iInterfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@end
