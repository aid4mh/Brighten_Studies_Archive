//
//  IPSEvaluateStrategy.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 12/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSEvaluateStrategy.h"
#import "IPSActionPlanController.h"


#define kTextLabelTag   1231
#define kPointLabelTag  1232
#define kHeaderMessage  @"Picture yourself using each strategy and consider:\n1. How much time and effort it would take.\n2. How comfortable you feel doing it.\n3. How likely it is you'll do it considering your schedule."


@interface IPSEvaluateStrategy ()

@property (nonatomic, retain) NSArray *strategies;
@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) NSMutableArray *ratings;

@end


@implementation IPSEvaluateStrategy

@synthesize ratings;
@synthesize tableView;
@synthesize strategies;

#pragma mark - Initialization

- (id)initWithStrategies:(NSArray *)iStrategies {
    self = [super init];
    if (self) {
        self.strategies = iStrategies;
      //  self.title = @"Evaluate Strategies";
        self.title = NSLocalizedString(@"EvaluateStrategies", @"");
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
    self.tableView = nil;
    self.strategies = nil;
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:IMAGE(@"TipButton") style:UIBarButtonItemStylePlain target:self action:@selector(showTips)];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = YES;
    }
    
    self.ratings = [NSMutableArray arrayWithObjects:
                    [NSNumber numberWithInt:0],
                    [NSNumber numberWithInt:0],
                    [NSNumber numberWithInt:0], nil];
    
    CGRect aFrame = self.view.bounds;
    if (!IS_iOS7) {
        aFrame.size.height -= 44;
    }
    self.tableView = [[UITableView alloc] initWithFrame:aFrame];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
    UIView *aHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 120)];
    [aHeaderView setBackgroundColor:RGBA_COLOR(254, 150, 140, 1)];
    
    UILabel *aHeaderLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 300, 120)];
    [aHeaderLabel setBackgroundColor:[UIColor clearColor]];
    [aHeaderLabel setFont:FONT(@"HelveticaNeue", 14)];
    [aHeaderLabel setTextColor:[UIColor whiteColor]];
    [aHeaderLabel setText:kHeaderMessage];
    [aHeaderView addSubview:aHeaderLabel];
    [aHeaderLabel setNumberOfLines:0];
    
    [[self tableView] setTableHeaderView:aHeaderView];
     */
}


- (void)viewDidAppear:(BOOL)iAnimated {
    [super viewDidAppear:iAnimated];
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
}


- (void)viewDidDisappear:(BOOL)iAnimated {
    [super viewDidDisappear:iAnimated];
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    }
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 1;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = 3;
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        NSDictionary *aStrategy = [[self strategies] objectAtIndex:theRow];
        NSString *aLocalizedLanguage = @"";
        NSString *aStrategyName = @"";
        
        NSArray *localizations = [[NSBundle mainBundle] preferredLocalizations];
        for (aLocalizedLanguage in localizations) {
            if ([aLocalizedLanguage isEqualToString:@"en"] ) {
                aStrategyName = [aStrategy valueForKey:@"name"];
            }else if ([aLocalizedLanguage isEqualToString:@"es"]){
                aStrategyName = [aStrategy valueForKey:@"name_es"];
            }
        }

        
        
        
      //  NSString *aStrategyName = [aStrategy valueForKey:@"name"];
        aStrategyName = [aStrategyName stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aStrategyName = [aStrategyName stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.textLabel.text = [NSString stringWithFormat:@"%@\n\n\n\n", aStrategyName];
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.font = FONT(@"HelveticaNeue", 17);
        aCell.textLabel.textColor = [UIColor blackColor];
        aCell.textLabel.numberOfLines = 0;
        
        CGFloat aCellHeight = [iTableView rectForRowAtIndexPath:iIndexPath].size.height;
        
        UIImage *aMaximumImage = [IMAGE(@"SliderMax") resizableImageWithCapInsets:UIEdgeInsetsMake(0, 15, 0, 15)];
        UIImage *aMinimumImage = [IMAGE(@"SliderMin") resizableImageWithCapInsets:UIEdgeInsetsMake(15, 20, 15, 20)];
        
        UISlider *aSlider = [[UISlider alloc] initWithFrame:CGRectMake(10, (aCellHeight - 30 - 30), 300, 30)];
        [aSlider addTarget:self action:@selector(changeValue:) forControlEvents:UIControlEventValueChanged];
        [aSlider setThumbImage:IMAGE(@"SliderThumb") forState:UIControlStateNormal];
        [aSlider setMaximumTrackImage:aMaximumImage forState:UIControlStateNormal];
        [aSlider setMinimumTrackImage:aMinimumImage forState:UIControlStateNormal];
        [aSlider setValue:0 animated:YES];
        [aSlider setContinuous:YES];
        [aSlider setMinimumValue:0];
        [aSlider setMaximumValue:4];
        [aCell addSubview:aSlider];
        aSlider.tag = theRow;
        
        UILabel *aPointLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 25, 25)];
        [aPointLabel setFont:FONT(@"HelveticaNeue-Bold", 16)];
        [aPointLabel setBackgroundColor:[UIColor clearColor]];
        [aPointLabel setTextAlignment:NSTextAlignmentCenter];
        [aPointLabel setTextColor:[UIColor whiteColor]];
        [aPointLabel setTag:kPointLabelTag];
        [aSlider addSubview:aPointLabel];
        
        [self changeValue:aSlider];
        
        UILabel *aTextLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, (aCellHeight - 25), 280, 20)];
        [aTextLabel setTextColor:RGBA_COLOR(213, 140, 49, 1)];
        [aTextLabel setBackgroundColor:[UIColor clearColor]];
        [aTextLabel setFont:FONT(@"HelveticaNeue-Bold", 14)];
        [aTextLabel setTag:kTextLabelTag];
        [aCell addSubview:aTextLabel];
    }
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
}


- (UIView *)tableView:(UITableView *)iTableView viewForHeaderInSection:(NSInteger)iSection {
    UILabel *aHeaderView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 30)];
    
    aHeaderView.backgroundColor = RGBA_COLOR(250, 230, 233, 1);
    //aHeaderView.text = @"  Rate your three strategies.";
    aHeaderView.text = NSLocalizedString(@"RateStrategies", @"");
    aHeaderView.font = FONT(@"HelveticaNeue", 14);
    aHeaderView.textColor = [UIColor grayColor];
    
    return aHeaderView;
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 0;
    NSInteger theRow = iIndexPath.row;
    
    NSDictionary *aStrategy = [[self strategies] objectAtIndex:theRow];
    NSString *aStrategyName = [[Session language] isEqualToString:@"en"] ? [aStrategy valueForKey:@"name"] : [aStrategy valueForKey:@"name_es"];
    aStrategyName = [aStrategyName stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    aStrategyName = [aStrategyName stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
  /*  CGSize aSize = [aStrategyName sizeWithFont:FONT(@"HelveticaNeue", 17) constrainedToSize:CGSizeMake(280, MAXFLOAT)];
    aHeight = (aSize.height + 15 + 70);*/
    CGSize maximumLabelSize = CGSizeMake(280,MAXFLOAT);
    CGRect textRect = [aStrategyName boundingRectWithSize:maximumLabelSize
                                            options:NSStringDrawingUsesLineFragmentOrigin
                                         attributes:@{NSFontAttributeName:HELVETICA_NEUE(17)}
                                            context:nil];
    CGSize expectedLabelSize = textRect.size;
    aHeight = (expectedLabelSize.height +20+70);
    return aHeight;
}


#pragma mark - Private

- (void)changeValue:(UISlider *)iSlider {
    UITableViewCell *aCell = [[self tableView] cellForRowAtIndexPath:[NSIndexPath indexPathForRow:iSlider.tag inSection:0]];
    UILabel *aTextLabel = (UILabel *)[aCell viewWithTag:kTextLabelTag];
    
    UILabel *aPointLabel = (UILabel *)[iSlider viewWithTag:kPointLabelTag];
    [iSlider bringSubviewToFront:aPointLabel];
    
    CGRect aTrackRect = [iSlider trackRectForBounds:iSlider.bounds];
    CGRect aThumbRect = [iSlider thumbRectForBounds:iSlider.bounds trackRect:aTrackRect value:iSlider.value];
    aPointLabel.center = CGPointMake((aThumbRect.origin.x + iSlider.frame.origin.x + 4),  (aThumbRect.origin.y + 13));
    
    NSInteger aValue = roundf(iSlider.value);
    
    switch (aValue) {
        case 0:
            aTextLabel.text = @"";
            aPointLabel.text = @"0";
            break;
            
        case 1:
            aPointLabel.text = @"1";
            //aTextLabel.text = @"Impossible";
            aTextLabel.text = NSLocalizedString(@"Impossible", @"");
            break;
            
        case 2:
            aPointLabel.text = @"2";
            //aTextLabel.text = @"Not sure";
            aTextLabel.text = NSLocalizedString(@"NotSure", @"");
            break;
            
        case 3:
            aPointLabel.text = @"3";
            //aTextLabel.text = @"I will try";
            aTextLabel.text = NSLocalizedString(@"IWillTry", @"");
            break;
            
        case 4:
            aPointLabel.text = @"4";
//            aTextLabel.text = @"Bring it on";
            aTextLabel.text = NSLocalizedString(@"BringItOn", @"");
            break;
            
        default:
            break;
    }
    
    [self setRating:[NSNumber numberWithInteger:aValue] atIndex:iSlider.tag];
}


- (void)setRating:(NSNumber *)iRating atIndex:(NSInteger)iIndex {
    [[self ratings] replaceObjectAtIndex:iIndex withObject:iRating];
    NSInteger aValue1 = [[[self ratings] objectAtIndex:0] integerValue];
    NSInteger aValue2 = [[[self ratings] objectAtIndex:1] integerValue];
    NSInteger aValue3 = [[[self ratings] objectAtIndex:2] integerValue];
    if ((aValue1 > 0) && (aValue2 > 0) && (aValue3 > 0)) {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(proceedToPlan)];
    } else {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:IMAGE(@"TipButton") style:UIBarButtonItemStylePlain target:self action:@selector(showTips)];
    }
}


- (void)proceedToPlan {
    NSNumber *aMaximumRating = [[self ratings] valueForKeyPath:@"@max.intValue"];
    NSInteger anIndex =[[self ratings] indexOfObject:aMaximumRating];
    NSDictionary *aStrategy = [[self strategies] objectAtIndex:anIndex];
    
    NSString *aLocalizedLanguage = @"";
    NSArray *localizations = [[NSBundle mainBundle] preferredLocalizations];
    for (aLocalizedLanguage in localizations) {
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            [[Session selections] setObject:[aStrategy valueForKey:@"name"] forKey:@"Strategy"];
        }else if ([aLocalizedLanguage isEqualToString:@"es"]){
            [[Session selections] setObject:[aStrategy valueForKey:@"name_es"] forKey:@"Strategy"];
        }
    }
    IPSActionPlanController *anActionPlanController = [[IPSActionPlanController alloc] initWithStrategy:aStrategy];
    [[self navigationController] pushViewController:anActionPlanController animated:YES];
}


- (void)showTips {
    [[[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"KHeaderMessage_EvaluateStrategy", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil] show];
}


#pragma mark - Orientation Method

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)iInterfaceOrientation {
    return (iInterfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@end
