//
//  IPSYoutubeController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 22/02/14.
//  Copyright (c) 2014 Wow Labz. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>
#import "IPSVideoController.h"
#import "IPSYoutubeView.h"


@interface IPSVideoController ()

@property (nonatomic, retain) MPMoviePlayerController *moviePlayer;

@end


@implementation IPSVideoController

#pragma mark - Initialization

- (id)init {
    self = [super init];
    if (self) {
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    CGFloat aWidth = SCREEN_HEIGHT;
    
    UIToolbar *aToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, aWidth, 35)];
    [self.view addSubview:aToolBar];
    [self loadToolBar:aToolBar];
    [self loadVideo];
}


#pragma mark - Private

- (void)dismissVideo {
    [[self moviePlayer] stop];
    [self dismissViewControllerAnimated:NO completion:nil];
}


- (void)loadToolBar:(UIToolbar *)iToolbar {
    UILabel *aTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 35)];
    [aTitleLabel setTextAlignment:NSTextAlignmentCenter];
    
    NSString *aTitle = NSLocalizedString(@"VideoTutorial", @"");
    NSDictionary *aTextAttribute = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [UIColor blackColor], UITextAttributeTextColor,
                                    [UIColor whiteColor], UITextAttributeTextShadowColor,
                                    [NSValue valueWithUIOffset:UIOffsetMake(0, 0.5)], UITextAttributeTextShadowOffset, nil];
    NSAttributedString *anAttributedTitle = [[NSAttributedString alloc] initWithString:aTitle attributes:aTextAttribute];
    [aTitleLabel setAttributedText:anAttributedTitle];

    
    UIBarButtonItem *aTitleBar = [[UIBarButtonItem alloc] initWithCustomView:aTitleLabel];
    UIBarButtonItem *aDoneBar = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                                                              target:self action:@selector(dismissVideo)];
    UIBarButtonItem *aSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                                                            target:nil action:nil];
    [iToolbar setItems:@[aSpace, aTitleBar, aSpace, aDoneBar]];
    
    
    
    [aDoneBar setTitleTextAttributes:aTextAttribute forState: UIControlStateNormal];
    if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
        [iToolbar setBarTintColor:NAVIGATION_COLOR];
        [iToolbar setTintColor:[UIColor blackColor]];
    } else {
        [iToolbar setTintColor:NAVIGATION_COLOR];
    }
}


- (void)loadVideo {
    CGFloat aWidth = SCREEN_HEIGHT;
    CGFloat aHeight = SCREEN_WIDTH;
    
    NSString *aVideoPath = [[NSBundle mainBundle] pathForResource:@"Video" ofType:@"mp4"];
    CGRect aVideoFrame = CGRectMake(0, 35, aWidth, (aHeight - 35));
    NSURL *aVideoURL = [NSURL fileURLWithPath:aVideoPath];
    
    self.moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:aVideoURL];
    [[self moviePlayer] setScalingMode:MPMovieScalingModeAspectFit];
    [self.moviePlayer setMovieSourceType:MPMovieSourceTypeFile];
    [self.moviePlayer setControlStyle:MPMovieControlStyleNone];
    [self.view addSubview:self.moviePlayer.view];
    [self.moviePlayer.view setFrame:aVideoFrame];
    [self.moviePlayer prepareToPlay];
    [[self moviePlayer] play];
}


#pragma mark - Orientation Method

- (BOOL)shouldAutorotate {
    return NO;
}


- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscapeLeft;
}


-  (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationLandscapeLeft;
}

@end
