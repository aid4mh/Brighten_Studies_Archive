//
//  IPSPlannedActionController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSPlannedActionController.h"


@interface IPSPlannedActionController ()

@property (nonatomic, assign) NSInteger selectedIndex;
@property (nonatomic, retain) UITableView *tableView;

@end


@implementation IPSPlannedActionController

@synthesize selectedIndex;
@synthesize tableView;

#pragma mark - Initialization

- (id)init {
    self = [super init];
    if (self) {
        // self.title = @"Action Plans";
        self.title = NSLocalizedString(@"ActionPlans", @"");
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
    self.tableView = nil;
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    self.selectedIndex = -1;
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = YES;
    }
    
    SET_BACKGROUND(self.view, self.view.bounds);
    self.navigationController.navigationBarHidden = NO;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGRect aFrame = self.view.bounds;
    if (IS_iOS7) {
        aFrame.size.height -= (44 + 20);
    }
    
    self.tableView = [[UITableView alloc] initWithFrame:aFrame];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}


- (void)viewWillAppear:(BOOL)iAnimated {
    [super viewWillAppear:iAnimated];
    self.navigationController.navigationBarHidden = NO;
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 1;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = [[Session actionPlans] count];
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.font = FONT(@"HelveticaNeue-Bold", 18);
        aCell.textLabel.textColor = [UIColor whiteColor];
        aCell.backgroundColor = [UIColor clearColor];
        aCell.textLabel.numberOfLines = 0;
    }
    
    NSDictionary *anActionPlan = [[Session actionPlans] objectAtIndex:theRow];
    NSString *aLocalizedLanguage = @"";
    NSString *aDescription = @"";
    NSArray *localizations = [[NSBundle mainBundle] preferredLocalizations];
    for (aLocalizedLanguage in localizations) {
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aDescription = [anActionPlan valueForKey:@"name"];
        }else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aDescription = [anActionPlan valueForKey:@"name_es"];
        }
    }
    aDescription = [aDescription stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    aDescription = [aDescription stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    aCell.textLabel.text = aDescription;
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    self.selectedIndex = iIndexPath.row;
    
    IPSPlanOptions *aPlanOptions = [[IPSPlanOptions alloc] init];
    [AppDelegate.window addSubview:aPlanOptions];
    aPlanOptions.delegate = self;
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 0;
    NSInteger theRow = iIndexPath.row;
    
    NSDictionary *anActionPlan = [[Session actionPlans] objectAtIndex:theRow];
    NSString *aTitle = [[Session language] isEqualToString:@"en"] ? [anActionPlan valueForKey:@"name"] : [anActionPlan valueForKey:@"name_es"];
    aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    /*  CGSize aSize = [aTitle sizeWithFont:FONT(@"HelveticaNeue-Bold", 18) constrainedToSize:CGSizeMake(270, MAXFLOAT)];*/
    CGSize maximumLabelSize = CGSizeMake(270,MAXFLOAT);
    CGRect textRect = [aTitle boundingRectWithSize:maximumLabelSize
                                           options:NSStringDrawingUsesLineFragmentOrigin
                                        attributes:@{NSFontAttributeName:HELVETICA_NEUE(17)}
                                           context:nil];
    CGSize expectedLabelSize = textRect.size;
    
    aHeight = (expectedLabelSize.height + 25);
    
    return aHeight;
}


#pragma mark - IPSOptionsDelegate

- (void)deletePlan {
    [[Session actionPlans] removeObjectAtIndex:[self selectedIndex]];
    [[self tableView] reloadData];
    [Session updateActionPlan];
}


- (void)reschedulePlan {
    [self addToCalendar];
}


#pragma mark - Private

- (void)addToCalendar {
    if (self.selectedIndex > -1) {
        EKEventStore *aStore = [[EKEventStore alloc] init];
        
        if([aStore respondsToSelector:@selector(requestAccessToEntityType:completion:)]) {
            // iOS 6
            [aStore requestAccessToEntityType:EKEntityTypeEvent
                                   completion:^(BOOL iGranted, NSError *iError) {
                                       if (iGranted) {
                                           dispatch_async(dispatch_get_main_queue(), ^{
                                               [self createEventAndPresentViewController:aStore];
                                           });
                                       }
                                   }];
        } else {
            // iOS 5
            [self createEventAndPresentViewController:aStore];
        }
    }
}


- (void)createEventAndPresentViewController:(EKEventStore *)iStore {
    EKEvent *anEvent = [self findOrCreateEvent:iStore];
    
    EKEventEditViewController *anEventController = [[EKEventEditViewController alloc] init];
    anEventController.event = anEvent;
    anEventController.eventStore = iStore;
    anEventController.editViewDelegate = self;
    
    [self presentViewController:anEventController animated:YES completion:nil];
}


- (EKEvent *)findOrCreateEvent:(EKEventStore *)iStore {
    
    NSString *aLocalizedLanguage = @"";
    NSString *aTitle = @"";
    NSArray *localizations = [[NSBundle mainBundle] preferredLocalizations];
    for (aLocalizedLanguage in localizations) {
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aTitle = [[[Session actionPlans] objectAtIndex:[self selectedIndex]] valueForKey:@"name"];
        }else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aTitle = [[[Session actionPlans] objectAtIndex:[self selectedIndex]] valueForKey:@"name_es"];
        }
    }
    aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    EKEvent *anEvent = [self findEventWithTitle:aTitle inEventStore:iStore];
    
    if (!anEvent) {
        anEvent = [EKEvent eventWithEventStore:iStore];
        
        // Next Date
        NSCalendarUnit aDateUnits = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
        NSDateComponents *aDateComponents = [[NSCalendar currentCalendar] components:aDateUnits fromDate:[NSDate date]];
        aDateComponents.day = (aDateComponents.day + 1);
        NSDate *aNextDate = [[NSCalendar currentCalendar] dateFromComponents:aDateComponents];
        NSString *aStrategy =@"";
        //  NSString *aStrategy = [[[Session actionPlans] objectAtIndex:[self selectedIndex]] valueForKey:@"name"];
        for (aLocalizedLanguage in localizations) {
            if ([aLocalizedLanguage isEqualToString:@"en"] ) {
                aStrategy = [[[Session actionPlans] objectAtIndex:[self selectedIndex]] valueForKey:@"name"];
            }else if ([aLocalizedLanguage isEqualToString:@"es"]){
                aStrategy = [[[Session actionPlans] objectAtIndex:[self selectedIndex]] valueForKey:@"name_es"];
            }
        }
        aStrategy = [aStrategy stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aStrategy = [aStrategy stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        EKAlarm *anAlarm =  [EKAlarm alarmWithRelativeOffset:36000]; // 10:00 AM
        
        anEvent.allDay = YES;
        anEvent.title = aTitle;
        [anEvent addAlarm:anAlarm];
        anEvent.endDate = aNextDate;
        anEvent.startDate = aNextDate;
        anEvent.calendar = [iStore defaultCalendarForNewEvents];
        anEvent.notes = [NSString stringWithFormat:@"Strategy: %@", aStrategy];
    }
    
    return anEvent;
}


- (EKEvent *)findEventWithTitle:(NSString *)iTitle inEventStore:(EKEventStore *)iStore {
    // Get the appropriate calendar
    NSCalendar *aCalendar = [NSCalendar currentCalendar];
    
    // Create the start range date components
    NSDateComponents *anOneDayAgoComponents = [[NSDateComponents alloc] init];
    anOneDayAgoComponents.day = -1;
    NSDate *oneDayAgo = [aCalendar dateByAddingComponents:anOneDayAgoComponents
                                                   toDate:[NSDate date]
                                                  options:0];
    
    // Create the end range date components
    NSDateComponents *anOneWeekFromNowComponents = [[NSDateComponents alloc] init];
    anOneWeekFromNowComponents.day = 120;
    NSDate *oneWeekFromNow = [aCalendar dateByAddingComponents:anOneWeekFromNowComponents
                                                        toDate:[NSDate date]
                                                       options:0];
    
    // Create the predicate from the event store's instance method
    NSPredicate *aPredicate = [iStore predicateForEventsWithStartDate:oneDayAgo
                                                              endDate:oneWeekFromNow
                                                            calendars:nil];
    
    // Fetch all events that match the predicate
    NSArray *anAllEvents = [iStore eventsMatchingPredicate:aPredicate];
    
    for (EKEvent *anEvent in anAllEvents) {
        if ([iTitle isEqualToString:anEvent.title]) {
            return anEvent;
        }
    }
    
    return nil;
}


#pragma mark - EKEventEditViewDelegate

- (void)eventEditViewController:(EKEventEditViewController *)iController didCompleteWithAction:(EKEventEditViewAction)iAction {
    [self dismissViewControllerAnimated:YES completion:^{
        if (iAction == EKEventEditViewActionSaved) {
            [[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Success!", @"") message:NSLocalizedString(@"AddActionToCalendar", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil] show];
        }
    }];
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@end
