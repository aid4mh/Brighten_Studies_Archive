//
//  IPSEvaluateStrategy.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 12/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface IPSEvaluateStrategy : UIViewController <UITableViewDataSource, UITableViewDelegate>

- (id)initWithStrategies:(NSArray *)iStrategies;

@end
