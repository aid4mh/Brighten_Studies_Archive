//
//  IPSProblemView.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 09/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSGoalController.h"
#import "IPSProblemView.h"


@interface IPSProblemView ()

@property (nonatomic, retain) NSMutableArray *problems;
@property (nonatomic, retain) NSString *domainID;

@end


@implementation IPSProblemView

@synthesize problems;
@synthesize domainID;

#pragma mark - Initialization

- (id)initWithDomain:(NSString *)iDomainID {
    CGRect aFrame = AppDelegate.window.frame;
    self = [super initWithFrame:aFrame];
    if (self) {
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.4];
        [self setDomainID:iDomainID];
        [self showProblems];
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
    self.problems = nil;
    self.domainID = nil;
}


#pragma mark - Private

- (void)showProblems {
    CGFloat aHeight = (self.frame.size.height / 2);
    CGFloat aYOffset = self.frame.size.height - aHeight;
    
    UIView *aView = [[UIView alloc] initWithFrame:CGRectMake(0, aYOffset, 320, aHeight)];
    aView.backgroundColor = [UIColor whiteColor];
    [self addSubview:aView];
    
    NSString *aDomainName = @"";
    NSString *aLocalizedLanguage = @"";

    for (NSDictionary *aDomain in [[Session content] valueForKey:@"domain"]) {
        if ([[aDomain valueForKey:@"id"] isEqualToString:[self domainID]]) {
            NSArray *localizations = [[NSBundle mainBundle] preferredLocalizations];
            for (aLocalizedLanguage in localizations) {
                if ([aLocalizedLanguage isEqualToString:@"en"] ) {
                    aDomainName = [aDomain valueForKey:@"name"];
                }else if ([aLocalizedLanguage isEqualToString:@"es"]){
                    aDomainName = [aDomain valueForKey:@"name_es"];
                }
            }
            
          //  aDomainName = [aDomain valueForKey:@"name"];
            break;
        }
    }
    
    self.problems = [NSMutableArray array];
    for (NSDictionary *aProblem in [[Session content] valueForKey:@"problems"]) {
        if ([[aProblem valueForKey:@"domain_id"] isEqualToString:[self domainID]]) {
            [[self problems] addObject:aProblem];
        }
    }
    
    UILabel *aTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 280, 20)];
    [aTitleLabel setTextColor:RGBA_COLOR(251, 118, 136, 1)];
    [aTitleLabel setBackgroundColor:[UIColor clearColor]];
    [aTitleLabel setFont:FONT(@"HelveticaNeue", 18)];
    [aTitleLabel setText:aDomainName];
    [aView addSubview:aTitleLabel];
    
    UILabel *aSubtitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 30, 280, 20)];
    [aSubtitleLabel setTextColor:RGBA_COLOR(122, 122, 122, 1)];
    [aSubtitleLabel setBackgroundColor:[UIColor clearColor]];
    [aSubtitleLabel setFont:FONT(@"HelveticaNeue", 16)];
    [aSubtitleLabel setText:NSLocalizedString(@"SpotProblem", @"")];
    [aView addSubview:aSubtitleLabel];
    
    UIButton *aCloseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [aCloseButton addTarget:self action:@selector(closePopup) forControlEvents:UIControlEventTouchUpInside];
    [aCloseButton setBackgroundImage:IMAGE(@"CloseButton") forState:UIControlStateNormal];
    [aCloseButton setFrame:CGRectMake(290, 0, 30, 30)];
    [aView addSubview:aCloseButton];
    
    UITableView *aTableView = [[UITableView alloc] initWithFrame:CGRectMake(10, 55, 300, (aHeight - 55))];
    aTableView.backgroundColor = [UIColor clearColor];
    [aView addSubview:aTableView];
    aTableView.dataSource = self;
    aTableView.delegate = self;
    
    CGRect aFrame = aView.frame;
    aFrame.origin.y = self.frame.size.height;
    aView.frame = aFrame;
    [UIView animateWithDuration:0.5 animations:^{
        CGRect aNewFrame = aView.frame;
        aNewFrame.origin.y = aYOffset;
        aView.frame = aNewFrame;
    }];
}


- (void)closePopup {
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0.1;
    } completion:^(BOOL finished) {
       [self removeFromSuperview];
    }];
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 1;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = [[self problems] count];
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        aCell.textLabel.textColor = RGBA_COLOR(104, 104, 104, 1.0);
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.font = FONT(@"HelveticaNeue-Bold", 18);
        aCell.textLabel.adjustsLetterSpacingToFitWidth = YES;
        aCell.textLabel.adjustsFontSizeToFitWidth = YES;
        aCell.textLabel.numberOfLines = 0;
    }
    NSDictionary *aProblem  = [[self problems] objectAtIndex:theRow];
    NSString *aLocalizedLanguage = @"";
    NSArray *localizations = [[NSBundle mainBundle] preferredLocalizations];
    for (aLocalizedLanguage in localizations) {
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aCell.textLabel.text = [aProblem valueForKey:@"name"];
        }else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aCell.textLabel.text = [aProblem valueForKey:@"name_es"];
        }
    }
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    
    [self closePopup];
    NSInteger theRow = iIndexPath.row;
    NSDictionary *aProblem  = [[self problems] objectAtIndex:theRow];
    NSString *aProblemID = [aProblem valueForKey:@"id"];
    
    [[Session selections] setObject:[aProblem valueForKey:@"name"] forKey:@"Problem"];
    IPSGoalController *aGoalController = [[IPSGoalController alloc] initWithProblem:aProblemID];
    [RootNavigation pushViewController:aGoalController animated:YES];
    aGoalController.domainID = [self domainID];
}


@end
