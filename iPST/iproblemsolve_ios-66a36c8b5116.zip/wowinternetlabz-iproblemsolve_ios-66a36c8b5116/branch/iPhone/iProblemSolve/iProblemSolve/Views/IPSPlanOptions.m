//
//  IPSPlanOptions.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSPlanOptions.h"


//#define TYPE @[@"I didn't do it", @"I started it but am not finished", @"I did it but it didn't go as planned", @"I did it and it went well"]
//#define OPTIONS @[@"Do you want to reschedule, solve it again or move on?", @"Do you want to reschedule, solve it again or move on?", @"That happens sometimes. As is said \"When you lose, do not lose the lesson\", so think about what you learned and try again. Would you like to solve it now or move on?", @"Stars float around with a That's Terrific! Let's solve another problem."]
//


#define TYPE @[NSLocalizedString(@"IDidn'tDo",@""), NSLocalizedString(@"StartedButDidn'tFinish",@""),NSLocalizedString(@"DidItButWentUnwell",@""), NSLocalizedString(@"DidItWentWell",@"")]

#define OPTIONS @[NSLocalizedString(@"Reschedule",@""),NSLocalizedString(@"Reschedule",@""), NSLocalizedString(@"SolveItOrMoveOn",@""), NSLocalizedString(@"SolveAnotherProblem",@"")]


@interface IPSPlanOptions ()

@end


@implementation IPSPlanOptions

@synthesize delegate;

#pragma mark - Initialization

- (id)init {
    CGRect aFrame = AppDelegate.window.frame;
    self = [super initWithFrame:aFrame];
    if (self) {
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.4];
        [self showOptions];
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
}


#pragma mark - Private

- (void)showOptions {
    CGFloat aHeight = (30 + (50 * 4));
    CGFloat aYOffset = self.frame.size.height - aHeight;
    
    UIView *aView = [[UIView alloc] initWithFrame:CGRectMake(0, aYOffset, 320, aHeight)];
    aView.backgroundColor = [UIColor whiteColor];
    [self addSubview:aView];
    
    UILabel *aTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 280, 20)];
    [aTitleLabel setTextColor:RGBA_COLOR(251, 118, 136, 1)];
    [aTitleLabel setBackgroundColor:[UIColor clearColor]];
    //[aTitleLabel setText:@"Status of this Action Plan?"];
    [aTitleLabel setText:NSLocalizedString(@"ActionPlanStatus", @"")];
    [aTitleLabel setFont:FONT(@"HelveticaNeue", 16)];
    [aView addSubview:aTitleLabel];
    
    UIButton *aCloseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [aCloseButton addTarget:self action:@selector(closePopup) forControlEvents:UIControlEventTouchUpInside];
    [aCloseButton setBackgroundImage:IMAGE(@"CloseButton") forState:UIControlStateNormal];
    [aCloseButton setFrame:CGRectMake(290, 0, 30, 30)];
    [aView addSubview:aCloseButton];
    
    UITableView *aTableView = [[UITableView alloc] initWithFrame:CGRectMake(10, 30, 300, (50 * 4))];
    aTableView.backgroundColor = [UIColor clearColor];
    aTableView.scrollEnabled = NO;
    [aView addSubview:aTableView];
    aTableView.dataSource = self;
    aTableView.delegate = self;
    
    CGRect aFrame = aView.frame;
    aFrame.origin.y = self.frame.size.height;
    aView.frame = aFrame;
    [UIView animateWithDuration:0.5 animations:^{
        CGRect aNewFrame = aView.frame;
        aNewFrame.origin.y = aYOffset;
        aView.frame = aNewFrame;
    }];
}


- (void)closePopup {
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0.1;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 1;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = [TYPE count];
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        aCell.textLabel.textColor = RGBA_COLOR(104, 104, 104, 1.0);
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.font = FONT(@"HelveticaNeue-Bold", 18);
        aCell.textLabel.adjustsLetterSpacingToFitWidth = YES;
        aCell.textLabel.adjustsFontSizeToFitWidth = YES;
        aCell.textLabel.numberOfLines = 0;
    }
    
    aCell.textLabel.text = TYPE[theRow];
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    
    NSString *aButton = (iIndexPath.row == 3) ? nil : @"Reschedule";
    [[[UIAlertView alloc] initWithTitle:nil message:OPTIONS[iIndexPath.row] delegate:self cancelButtonTitle:aButton otherButtonTitles:NSLocalizedString(@"Remove", @""), nil] show];
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 50;
    return aHeight;
}


#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)iAlertView clickedButtonAtIndex:(NSInteger)iButtonIndex {
    NSString *aTitle = [iAlertView buttonTitleAtIndex:iButtonIndex];
    if ([aTitle isEqualToString:NSLocalizedString(@"Remove", @"")]) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(deletePlan)]) {
            [[self delegate] deletePlan];
        }
    } else {
        if (self.delegate && [self.delegate respondsToSelector:@selector(reschedulePlan)]) {
            [[self delegate] reschedulePlan];
        }
    }
    
    [self closePopup];
}


@end
