//
//  IPSLoginView.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 22/02/14.
//  Copyright (c) 2014 Wow Labz. All rights reserved.
//


#import "NSString+MD5.h"
#import "IPSTextField.h"
#import "IPSLoginView.h"


#define kPasswordTag        12120
#define kUsernameTag        12121


@interface IPSLoginView ()

@property (nonatomic, retain) UIImageView *sunView;
@property (nonatomic, retain) IPSTextField *emailField;
@property (nonatomic, retain) IPSTextField *passwordField;

@property (nonatomic, assign) CGRect emailFrame;
@property (nonatomic, assign) CGRect passwordFrame;

@property (nonatomic, retain) UIImageView *line1View;
@property (nonatomic, retain) UIImageView *line2View;

@end


@implementation IPSLoginView

#pragma mark - Initialization

@synthesize sunView;
@synthesize line1View;
@synthesize line2View;
@synthesize emailFrame;
@synthesize emailField;
@synthesize passwordFrame;
@synthesize passwordField;

- (id)init {
    CGRect aFrame = AppDelegate.window.bounds;
    self = [super initWithFrame:aFrame];
    if (self) {
        [self layoutScreen];
        SET_BACKGROUND(self, self.bounds);
    }
    return self;
}


#pragma mark - Desctruction

- (void)dealloc {
    self.passwordField = nil;
    self.emailField = nil;
    self.line1View = nil;
    self.line2View = nil;
    self.sunView = nil;
}


#pragma mark - Private

- (void)layoutScreen {
    CGFloat aButtonYOffset = (self.bounds.size.height - 84);
    
    self.sunView = [[UIImageView alloc] initWithImage:IMAGE(@"Sun")];
    self.sunView.frame = CGRectMake(65, (self.center.y - 50 - 95), 190, 190);
    [self addSubview:self.sunView];
    
    [UIView animateWithDuration:1.5 animations:^{
        CGRect aFrame = self.sunView.frame;
        aFrame.origin.y -= 30;
        self.sunView.frame = aFrame;
    } completion:^(BOOL finished) {
    }];
    
    self.emailFrame = CGRectMake(37.5, (aButtonYOffset - 130), 245, 35);
    self.emailField = [[IPSTextField alloc] initWithFrame:self.emailFrame];
    self.emailField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.emailField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
    self.emailField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.emailField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.emailField.font = FONT(@"HelveticaNeue-CondensedBold", 22);
    self.emailField.placeholder = NSLocalizedString(@"UserID", @"");
    self.emailField.keyboardType = UIKeyboardTypeEmailAddress;
    self.emailField.textColor = [UIColor whiteColor];
    self.emailField.returnKeyType = UIReturnKeyNext;
    [self addSubview:self.emailField];
    self.emailField.delegate = self;
    
    self.passwordFrame = CGRectMake(37.5, (aButtonYOffset - 65), 245, 35);
    self.passwordField = [[IPSTextField alloc] initWithFrame:self.passwordFrame];
    self.passwordField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.passwordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.passwordField.placeholder = NSLocalizedString(@"Password", @"");
    self.passwordField.font = FONT(@"HelveticaNeue-CondensedBold", 22);
    self.passwordField.textColor = [UIColor whiteColor];
    self.passwordField.returnKeyType = UIReturnKeyDone;

    self.passwordField.secureTextEntry = YES;
    [self addSubview:self.passwordField];
    self.passwordField.delegate = self;
    
    UIButton *aLoginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [aLoginButton addTarget:self action:@selector(continueLogin) forControlEvents:UIControlEventTouchUpInside];
    [aLoginButton setBackgroundImage:IMAGE(@"LoginButton") forState:UIControlStateNormal];
    [aLoginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [[aLoginButton titleLabel] setFont:FONT(@"HelveticaNeue-CondensedBold", 22)];
    [aLoginButton setFrame:CGRectMake(37.5, aButtonYOffset, 245, 44)];
   // [aLoginButton setTitle:@"LOGIN" forState:UIControlStateNormal];
    [aLoginButton setTitle:NSLocalizedString(@"Login", @"") forState:UIControlStateNormal];

    [self addSubview:aLoginButton];
    
    self.line1View = [[UIImageView alloc] initWithFrame:CGRectMake(37.5, CGRectGetMaxY(self.emailField.frame), 245, 1)];
    [self.line1View setImage:IMAGE(@"LoginLine")];
    [self addSubview:self.line1View];
    
    self.line2View = [[UIImageView alloc] initWithFrame:CGRectMake(37.5, CGRectGetMaxY(self.passwordField.frame), 245, 1)];
    [self.line2View setImage:IMAGE(@"LoginLine")];
    [self addSubview:self.line2View];
}


- (void)continueLogin {
    if (self.emailField.text && self.emailField.text.length > 0) {
        if (self.passwordField.text && self.passwordField.text.length > 0) {
            [self loginUser];
        } else {
             UIAlertView *anAlertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Error!", @"") message:NSLocalizedString(@"PasswordError", @"")                                                          delegate:self cancelButtonTitle:NSLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil];
            anAlertView.tag = kPasswordTag;
            [anAlertView show];
        }
    } else {
        UIAlertView *anAlertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Error!", @"") message:NSLocalizedString(@"UserIDError", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil];

        anAlertView.tag = kUsernameTag;
        [anAlertView show];
    }
}


- (void)loginUser {
    BOOL isValidUser = NO;
    NSError *anError = nil;
    NSString *anUsername = [[[self emailField] text] MD5];
    NSString *aPassword = [[[self passwordField] text] MD5];
    NSString *aFilePath = [[NSBundle mainBundle] pathForResource:@"LoginCredentials" ofType:@"csv"];
    NSString *aLoginData = [NSString stringWithContentsOfFile:aFilePath encoding:NSUTF8StringEncoding error:&anError];
    
    NSArray *anAllCredentials = [aLoginData componentsSeparatedByString:@"\n"];
    for (NSString *aCredential in anAllCredentials) {
        NSString *aUserCredential = [NSString stringWithString:aCredential];
        aUserCredential = [aUserCredential stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aUserCredential = [aUserCredential stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        NSArray *anUserData = [aUserCredential componentsSeparatedByString:@","];
        if (anUserData.count == 2) {
            if ([[anUserData objectAtIndex:0] isEqualToString:anUsername] &&
                [[anUserData objectAtIndex:1] isEqualToString:aPassword]) {
                isValidUser = YES;
                break;
            }
        }
    }
    
    if (isValidUser) {
        [Session setUserID:[[self emailField] text]];
        
        NSUserDefaults *anUserDefaults = [NSUserDefaults standardUserDefaults];
        [anUserDefaults setObject:[Session userID] forKey:USER_ID];
        [anUserDefaults synchronize];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:SUCCESSFUL_LOGIN object:self];
    } else {
         UIAlertView *anAlertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Error!", @"") message:NSLocalizedString(@"LoginError", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OkButtonTitle", @"")  otherButtonTitles:nil];
        anAlertView.tag = kUsernameTag;
        [anAlertView show];
    }
}


#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)iTextField {
    [UIView animateWithDuration:1 animations:^{
        self.sunView.alpha = 0.0;
        CGFloat aYOffset = self.sunView.frame.origin.y + 25;
        
        CGRect anEmailFrame = self.emailFrame;
        anEmailFrame.origin.y = aYOffset;
        self.emailField.frame = anEmailFrame;
        
        CGRect aPasswordFrame = self.passwordFrame;
        aPasswordFrame.origin.y = aYOffset + 65;
        self.passwordField.frame = aPasswordFrame;
        
        self.line1View.frame = CGRectMake(37.5, CGRectGetMaxY(self.emailField.frame), 245, 1);
        self.line2View.frame = CGRectMake(37.5, CGRectGetMaxY(self.passwordField.frame), 245, 1);
    }];
    
    return YES;
}


- (BOOL)textFieldShouldReturn:(UITextField *)iTextField {
    if (iTextField == self.emailField) {
        [self.passwordField becomeFirstResponder];
    } else if (iTextField == self.passwordField) {
        [self.passwordField resignFirstResponder];
        [UIView animateWithDuration:1 animations:^{
            self.sunView.alpha = 1.0;
            self.emailField.frame = self.emailFrame;
            self.passwordField.frame = self.passwordFrame;
            self.line1View.frame = CGRectMake(37.5, CGRectGetMaxY(self.emailField.frame), 245, 1);
            self.line2View.frame = CGRectMake(37.5, CGRectGetMaxY(self.passwordField.frame), 245, 1);
        }];
    }
    
    return YES;
}


#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)iAlertView clickedButtonAtIndex:(NSInteger)iButtonIndex {
    if (iAlertView.tag == kPasswordTag) {
        [self.passwordField becomeFirstResponder];
    } else if (iAlertView.tag == kUsernameTag) {
        [self.emailField becomeFirstResponder];
    }
}


@end
