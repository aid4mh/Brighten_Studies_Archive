//
//  IPSMoodView.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSMoodView.h"


@interface IPSMoodView ()

@property (nonatomic, retain) UIButton *verySadButton;
@property (nonatomic, retain) UIButton *happyButton;
@property (nonatomic, retain) UIButton *greatButton;
@property (nonatomic, retain) UIButton *goodButton;
@property (nonatomic, retain) UIButton *sadButton;
@property (nonatomic, retain) UIButton *okButton;

@end


@implementation IPSMoodView

@synthesize verySadButton;
@synthesize happyButton;
@synthesize greatButton;
@synthesize goodButton;
@synthesize sadButton;
@synthesize okButton;

#pragma mark - Initialization

- (id)init {
    CGRect aFrame = AppDelegate.window.bounds;
    self = [super initWithFrame:aFrame];
    if (self) {
        [self layoutMoods];
        SET_BACKGROUND(self, self.bounds);
    }
    return self;
}


#pragma mark - Desctruction

- (void)dealloc {
    self.verySadButton = nil;
    self.happyButton = nil;
    self.greatButton = nil;
    self.goodButton = nil;
    self.sadButton = nil;
    self.okButton = nil;
}


#pragma mark - Private

- (void)layoutMoods {
    UILabel *aMoodLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 130, 120)];
    aMoodLabel.font = FONT(@"HelveticaNeue-CondensedBold", 30);
    aMoodLabel.backgroundColor = [UIColor clearColor];
    aMoodLabel.textAlignment = NSTextAlignmentCenter;
//    aMoodLabel.text = @"What's\nyour mood\ntoday?";
    aMoodLabel.text = NSLocalizedString(@"WhatsYourMood", @"");

    aMoodLabel.textColor = [UIColor whiteColor];
    aMoodLabel.adjustsFontSizeToFitWidth = YES;
    aMoodLabel.center = self.center;
    aMoodLabel.numberOfLines = 0;
    [self addSubview:aMoodLabel];
    
    CGRect aFrame = aMoodLabel.frame;
    
    self.verySadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.verySadButton addTarget:self action:@selector(selectVerySad) forControlEvents:UIControlEventTouchUpInside];
    [self.verySadButton setBackgroundImage:IMAGE(@"VerySad") forState:UIControlStateNormal];
    [self.verySadButton setFrame:CGRectMake(10, (CGRectGetMinY(aFrame) - 70), 92, 92)];
    [self addSubview:self.verySadButton];
    
    self.sadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.sadButton addTarget:self action:@selector(selectSad) forControlEvents:UIControlEventTouchUpInside];
    [self.sadButton setBackgroundImage:IMAGE(@"Sad") forState:UIControlStateNormal];
    [self.sadButton setFrame:CGRectMake((CGRectGetMidX(aFrame) - 46), (CGRectGetMinY(aFrame) - 120), 92, 92)];
    [self addSubview:self.sadButton];
    
    self.okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.okButton addTarget:self action:@selector(selectOk) forControlEvents:UIControlEventTouchUpInside];
    [self.okButton setBackgroundImage:IMAGE(@"Ok") forState:UIControlStateNormal];
    [self.okButton setFrame:CGRectMake((320 - 92 - 10), (CGRectGetMinY(aFrame) - 70), 92, 92)];
    [self addSubview:self.okButton];
    
    self.goodButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.goodButton addTarget:self action:@selector(selectGood) forControlEvents:UIControlEventTouchUpInside];
    [self.goodButton setBackgroundImage:IMAGE(@"Good") forState:UIControlStateNormal];
    [self.goodButton setFrame:CGRectMake(10, (CGRectGetMaxY(aFrame) - 22), 92, 92)];
    [self addSubview:self.goodButton];
    
    self.happyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.happyButton addTarget:self action:@selector(selectHappy) forControlEvents:UIControlEventTouchUpInside];
    [self.happyButton setBackgroundImage:IMAGE(@"Happy") forState:UIControlStateNormal];
    [self.happyButton setFrame:CGRectMake((CGRectGetMidX(aFrame) - 46), (CGRectGetMaxY(aFrame) + 28), 92, 92)];
    [self addSubview:self.happyButton];
    
    self.greatButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.greatButton addTarget:self action:@selector(selectGreat) forControlEvents:UIControlEventTouchUpInside];
    [self.greatButton setBackgroundImage:IMAGE(@"Great") forState:UIControlStateNormal];
    [self.greatButton setFrame:CGRectMake((320 - 92 - 10), (CGRectGetMaxY(aFrame) - 22), 92, 92)];
    [self addSubview:self.greatButton];
    
    UILabel *aVerySadLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.verySadButton.frame), CGRectGetMaxY(self.verySadButton.frame), 92, 20)];
    aVerySadLabel.textColor = RGBA_COLOR(238, 216, 223, 1);
    aVerySadLabel.backgroundColor = [UIColor clearColor];
    aVerySadLabel.font = FONT(@"HelveticaNeue-Bold", 15);
    aVerySadLabel.textAlignment = NSTextAlignmentCenter;
   // aVerySadLabel.text = @"Very Sad";
    aVerySadLabel.text = NSLocalizedString(@"VerySad", @"");
    [self addSubview:aVerySadLabel];
    
    UILabel *aSadLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.sadButton.frame), CGRectGetMaxY(self.sadButton.frame), 92, 20)];
    aSadLabel.textColor = RGBA_COLOR(238, 216, 223, 1);
    aSadLabel.backgroundColor = [UIColor clearColor];
    aSadLabel.font = FONT(@"HelveticaNeue-Bold", 15);
    aSadLabel.textAlignment = NSTextAlignmentCenter;
   // aSadLabel.text = @"Sad";
    aSadLabel.text = NSLocalizedString(@"Sad", @"");
    [self addSubview:aSadLabel];
    
    UILabel *aOkLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.okButton.frame), CGRectGetMaxY(self.okButton.frame), 92, 20)];
    aOkLabel.textColor = RGBA_COLOR(238, 216, 223, 1);
    aOkLabel.backgroundColor = [UIColor clearColor];
    aOkLabel.font = FONT(@"HelveticaNeue-Bold", 15);
    aOkLabel.textAlignment = NSTextAlignmentCenter;
  //  aOkLabel.text = @"Ok";
    aOkLabel.text = NSLocalizedString(@"OkButtonTitle", @"");
    [self addSubview:aOkLabel];
    
    UILabel *aGoodLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.goodButton.frame), CGRectGetMaxY(self.goodButton.frame), 92, 20)];
    aGoodLabel.textColor = RGBA_COLOR(238, 216, 223, 1);
    aGoodLabel.backgroundColor = [UIColor clearColor];
    aGoodLabel.font = FONT(@"HelveticaNeue-Bold", 15);
    aGoodLabel.textAlignment = NSTextAlignmentCenter;
    aGoodLabel.text = NSLocalizedString(@"Good", @"");
    [self addSubview:aGoodLabel];
    
    UILabel *aHappyLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.happyButton.frame), CGRectGetMaxY(self.happyButton.frame), 92, 20)];
    aHappyLabel.textColor = RGBA_COLOR(238, 216, 223, 1);
    aHappyLabel.font = FONT(@"HelveticaNeue-Bold", 15);
    aHappyLabel.backgroundColor = [UIColor clearColor];
    aHappyLabel.textAlignment = NSTextAlignmentCenter;
    aHappyLabel.text = NSLocalizedString(@"Happy", @"");
    [self addSubview:aHappyLabel];
    
    UILabel *aGreatLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.greatButton.frame), CGRectGetMaxY(self.greatButton.frame), 92, 20)];
    aGreatLabel.textColor = RGBA_COLOR(238, 216, 223, 1);
    aGreatLabel.backgroundColor = [UIColor clearColor];
    aGreatLabel.font = FONT(@"HelveticaNeue-Bold", 15);
    aGreatLabel.textAlignment = NSTextAlignmentCenter;
    aGreatLabel.text = NSLocalizedString(@"Great", @"");
    [self addSubview:aGreatLabel];
}


- (void)selectVerySad {
    [Session updateMood:-3];
    [self dismissView];
}


- (void)selectSad {
    [Session updateMood:-2];
    [self dismissView];
}


- (void)selectOk {
    [Session updateMood:-1];
    [self dismissView];
}


- (void)selectGood {
    [Session updateMood:1];
    [self dismissView];
}


- (void)selectHappy {
    [Session updateMood:2];
    [self dismissView];
}


- (void)selectGreat {
    [Session updateMood:3];
    [self dismissView];
}


- (void)dismissView {
    [self removeFromSuperview];
    [[NSNotificationCenter defaultCenter] postNotificationName:CHECK_ACTION_PLAN object:nil];
}

@end
