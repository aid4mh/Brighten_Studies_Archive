//
//  NSFileManager-Additions.m
//
//  Created by Roshit Omanakuttan on 14/01/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//

#import "NSFileManager-Additions.h"

@implementation NSFileManager(Additions)


- (NSString *)findOrCreateDirectory:(NSSearchPathDirectory)iSearchPath inDomain:(NSSearchPathDomainMask)iDomain appendPathComponent:(NSString *)iAppend error:(NSError **)iError {
	NSArray *aPathList = NSSearchPathForDirectoriesInDomains(iSearchPath, iDomain, YES);
	if (aPathList.count == 0)
		return nil;
	
	NSString *aPath = [aPathList objectAtIndex:0];
	if (iAppend) {
		aPath = [aPath stringByAppendingPathComponent:iAppend];
	}
	// Ensure the path exists, else create
	BOOL isDirectory;
	BOOL doesExist = [self fileExistsAtPath:aPath isDirectory:&isDirectory];
	if (!doesExist || !isDirectory) {
		if (doesExist) {
			return nil;
		}
		
		// Create the path if not existing
		NSError *anError = nil;
		[self createDirectoryAtPath:aPath withIntermediateDirectories:YES attributes:nil error:&anError];
		if (anError) {
			if (iError)
				*iError = anError;
			return nil;
		}
	}
	
	if (iError) { *iError = nil; }
	return aPath;
}


- (NSString *)applicationSupportDirectory {
	NSString *aReturnVal = nil;
	NSString *anAppName = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleExecutable"];
	NSError *anError;
	aReturnVal = [self findOrCreateDirectory:NSApplicationSupportDirectory inDomain:NSUserDomainMask appendPathComponent:anAppName error:&anError];
	return aReturnVal;
}

@end
