//
//  IPSSession.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 06/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSSession.h"

static IPSSession *sharedIPSSession = nil;

@implementation IPSSession

@synthesize contentStatus;
@synthesize userActivity;
@synthesize actionPlans;
@synthesize selections;
@synthesize content;
@synthesize userID;
@synthesize moods;

#pragma mark - Singleton

+ (IPSSession *)sharedIPSSession {
	@synchronized(self) {
		if (sharedIPSSession == nil) {
			sharedIPSSession = [[IPSSession alloc] init];
		}
	}
    
	return sharedIPSSession;
}


#pragma mark - Destruction

- (void)dealloc {
    self.userActivity = nil;
    self.actionPlans = nil;
    self.content = nil;
    self.userID = nil;
    self.moods = nil;
}


#pragma mark - Public

- (void)loadAppContent {
    self.contentStatus = CONTENT_STATUS_LOADING;
    
    [AppDelegate showLoading];
    
    NSString *anEndPoint = [NSString stringWithFormat:GET_DUMP_API, [self userID]];
    NSString *anURL = [NSString stringWithFormat:@"%@%@", BASE_URL, anEndPoint];
    
    IPSURLHandler *anURLHandler = [[IPSURLHandler alloc] initWithURLString:anURL];
    [anURLHandler setDelegate:self];
    [anURLHandler sendRequest];
}


- (void)loadActionPlan {
    NSString *aPath  = [NSString stringWithFormat:@"%@/ActionPlan.plist", ApplicationSupport];
    if ([[NSFileManager defaultManager] fileExistsAtPath:aPath isDirectory:NO]) {
        [self setActionPlans:[NSMutableArray arrayWithContentsOfFile:aPath]];
    } else {
        [self setActionPlans:[NSMutableArray array]];
    }
}


- (void)updateActionPlan {
    NSString *aPath  = [NSString stringWithFormat:@"%@/ActionPlan.plist", ApplicationSupport];
    [[self actionPlans] writeToFile:aPath atomically:YES];
}


- (void)loadMood {
    NSString *aPath  = [NSString stringWithFormat:@"%@/Mood.plist", ApplicationSupport];
    if ([[NSFileManager defaultManager] fileExistsAtPath:aPath isDirectory:NO]) {
        [self setMoods:[NSMutableArray arrayWithContentsOfFile:aPath]];
    } else {
        [self setMoods:[NSMutableArray array]];
    }
}


- (BOOL)shouldCheckMood {
    BOOL aStatus = YES;
    
    if ([[self moods] count] > 0) {
        NSCalendarUnit aDateUnits = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
        NSDateComponents *aDateComponents = [[NSCalendar currentCalendar] components:aDateUnits fromDate:[NSDate date]];
        
        NSDictionary *aMood = [[self moods] lastObject];
        NSDate *aLastDate = [aMood valueForKey:@"Date"];
        NSDateComponents *aLastDateComponents = [[NSCalendar currentCalendar] components:aDateUnits fromDate:aLastDate];
        
        if (aLastDateComponents.day == aDateComponents.day &&
            aLastDateComponents.month == aDateComponents.month &&
            aLastDateComponents.year == aDateComponents.year) {
            aStatus = NO;
        }
    }
    
    return aStatus;
}


- (void)updateMood:(NSInteger)iMood {
    NSDictionary *aMood = @{@"Mood": [NSNumber numberWithInteger:iMood], @"Date": [NSDate date]};
    [[self moods] addObject:aMood];
    
    NSString *aPath  = [NSString stringWithFormat:@"%@/Mood.plist", ApplicationSupport];
    [[self moods] writeToFile:aPath atomically:YES];
}


- (NSString *)UTCDateStringForDate:(NSDate *)iDate {
    NSDateFormatter *aDateFormatter = [[NSDateFormatter alloc] init];
    // [aDateFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    [aDateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZZZ"];
    NSString *aDateString = [aDateFormatter stringFromDate:iDate];
    return aDateString;
}


- (NSString *)UTCDateString {
    return [self UTCDateStringForDate:[NSDate date]];
}


- (NSString *)language {
    /*
    NSArray *aLocalizations = [[NSBundle mainBundle] preferredLocalizations];
    for (NSString *aLocalizedLanguage in aLocalizations) {
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            return @"en";
        } else if ([aLocalizedLanguage isEqualToString:@"es"]){
            return @"es";
        }
    }
     return @"en";
    */
    
    NSString *aLanguage = [[[NSUserDefaults standardUserDefaults] valueForKey:@"AppleLanguages"] firstObject];
    return aLanguage;
}


#pragma mark - IPSURLDelegate

- (void)urlHandler:(IPSURLHandler *)iHandler didFinishLoadingWithResponse:(id)iResponse; {
    NSLog(@"iResponse: %@", iResponse);
    [AppDelegate removeLoading];
    
    if (iResponse && [iResponse isKindOfClass:[NSDictionary class]]) {
        if (iResponse && [[iResponse valueForKey:@"stat"] isEqualToString:@"true"] &&
            [iResponse valueForKey:@"dump"]) {
            self.contentStatus = CONTENT_STATUS_COMPLETE;
            [self setContent:[NSMutableDictionary dictionaryWithDictionary:[iResponse valueForKey:@"dump"]]];
            
            NSDateFormatter *aDateFormat = [[NSDateFormatter alloc] init];
            [aDateFormat setDateFormat:@"dd-MM-yyyy"];
            NSString *aDate = [aDateFormat stringFromDate:[NSDate date]];
            
            NSUserDefaults *anUserDefault = [NSUserDefaults standardUserDefaults];
            [anUserDefault setObject:aDate forKey:CONTENT_DATE];
            [anUserDefault synchronize];
            
            NSString *aPath  = [NSString stringWithFormat:@"%@/Content.plist", ApplicationSupport];
            [[self content] writeToFile:aPath atomically:YES];
        }
    } else {
        self.contentStatus = CONTENT_STATUS_FAILED;
    }
    
    if (!self.content) {
        NSString *aPath  = [NSString stringWithFormat:@"%@/Content.plist", ApplicationSupport];
        if ([[NSFileManager defaultManager] fileExistsAtPath:aPath isDirectory:NO]) {
            self.contentStatus = CONTENT_STATUS_COMPLETE;
            [self setContent:[NSMutableDictionary dictionaryWithContentsOfFile:aPath]];
        }
    }
}


- (void)urlHandler:(IPSURLHandler *)iHandler didFailToLoadWithError:(NSError *)iError {
    [AppDelegate removeLoading];
    
    if (iError) {
        self.contentStatus = CONTENT_STATUS_FAILED;
    }
    
    if (!self.content) {
        NSString *aPath  = [NSString stringWithFormat:@"%@/Content.plist", ApplicationSupport];
        if ([[NSFileManager defaultManager] fileExistsAtPath:aPath isDirectory:NO]) {
            self.contentStatus = CONTENT_STATUS_COMPLETE;
            [self setContent:[NSMutableDictionary dictionaryWithContentsOfFile:aPath]];
        }
    }
}

@end
