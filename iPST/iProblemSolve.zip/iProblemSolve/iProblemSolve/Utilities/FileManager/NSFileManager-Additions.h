//
//  NSFileManager-Additions.h
//
//  Created by Roshit Omanakuttan on 14/01/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSFileManager(Additions)

- (NSString *)findOrCreateDirectory:(NSSearchPathDirectory)iSearchPath inDomain:(NSSearchPathDomainMask)iDomain appendPathComponent:(NSString *)iAppend error:(NSError **)iError;

- (NSString *)applicationSupportDirectory;

@end
