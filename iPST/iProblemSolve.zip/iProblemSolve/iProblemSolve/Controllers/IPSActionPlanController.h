//
//  IPSActionPlanController.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <EventKit/EventKit.h>
#import <EventKitUI/EventKitUI.h>


@interface IPSActionPlanController : UIViewController <UITableViewDataSource, UITableViewDelegate, EKEventEditViewDelegate>

- (id)initWithStrategy:(NSDictionary *)iStrategy;

@end
