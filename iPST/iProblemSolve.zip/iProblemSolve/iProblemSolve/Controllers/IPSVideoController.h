//
//  IPSYoutubeController.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 22/02/14.
//  Copyright (c) 2014 Wow Labz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IPSVideoController : UIViewController

@end
