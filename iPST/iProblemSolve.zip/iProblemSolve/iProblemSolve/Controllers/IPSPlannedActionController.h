//
//  IPSPlannedActionController.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import <EventKitUI/EventKitUI.h>
#import <EventKit/EventKit.h>
#import "IPSPlanOptions.h"
#import <UIKit/UIKit.h>


@interface IPSPlannedActionController : UIViewController <UITableViewDataSource, UITableViewDelegate, IPSOptionsDelegate, EKEventEditViewDelegate>

@end
