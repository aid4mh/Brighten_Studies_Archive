//
//  IPSStrategyController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 12/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSEvaluateStrategy.h"
#import "IPSStrategyController.h"


#define kTextViewTag    1231


@interface IPSStrategyController () <IPSURLDelegate>

@property (nonatomic, retain) NSMutableArray *selectedStrategies;
@property (nonatomic, retain) NSMutableArray *strategies;
@property (nonatomic, retain) UIButton *evaluateButton;
@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) UIView *inputView;
@property (nonatomic, retain) NSString *goalID;

@end


@implementation IPSStrategyController

@synthesize goalID;
@synthesize domainID;
@synthesize problemID;
@synthesize tableView;
@synthesize inputView;
@synthesize strategies;
@synthesize evaluateButton;
@synthesize selectedStrategies;

#pragma mark - Initialization

- (id)initWithGoal:(NSString *)iGoalID {
    self = [super init];
    if (self) {
        self.goalID = iGoalID;
        //self.title = @"Pick Strategies";
        self.title = STLocalizedString(@"PickStrategies", @"");
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
    self.goalID = nil;
    self.domainID = nil;
    self.problemID = nil;
    self.tableView = nil;
    self.inputView = nil;
    self.strategies = nil;
    self.evaluateButton = nil;
    self.selectedStrategies = nil;
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = YES;
    }
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:IMAGE(@"TipButton") style:UIBarButtonItemStylePlain target:self action:@selector(showTips)];
    
    self.strategies = [NSMutableArray array];
    self.selectedStrategies = [NSMutableArray array];
    
    for (NSDictionary *aStrategy in [[Session content] valueForKey:@"strategies"]) {
        NSString *aGoalID = [aStrategy valueForKey:@"goal_id"];
        if ([aGoalID integerValue] == [self.goalID integerValue]) {
            [[self strategies] addObject:aStrategy];
        }
    }
    CGRect aFrame = self.view.bounds;
    if (!IS_iOS7) {
        aFrame.size.height -= 44;
    }
    self.tableView = [[UITableView alloc] initWithFrame:aFrame];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 2;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = 1;
    if (iSection == 1) {
        aRowCount = self.strategies.count;
    }
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.textColor = [UIColor blackColor];
        aCell.textLabel.numberOfLines = 0;
        
        if (theSection == 0) {
            UIImageView *aPenView = [[UIImageView alloc] initWithImage:IMAGE(@"PenIcon")];
            [aPenView setFrame:CGRectMake(6, 0, 30, 30)];
            [aCell addSubview:aPenView];
            
            aCell.textLabel.textColor = [UIColor grayColor];
            aCell.textLabel.font = FONT(@"HelveticaNeue", 14);
           // aCell.textLabel.text = @"     Add your own strategy.\n\n\n";
            aCell.textLabel.text = STLocalizedString(@"AddStrategy", @"");
            
            self.inputView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 60)];
            self.inputView.backgroundColor = [UIColor whiteColor];
            [aCell addSubview:self.inputView];
            
            UITextView *aTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, 280, 60)];
            aTextView.backgroundColor = [UIColor whiteColor];
            aTextView.font = FONT(@"HelveticaNeue", 14);
            [self.inputView addSubview:aTextView];
            aTextView.tag = kTextViewTag;
            
            UIButton *aDoneButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [aDoneButton addTarget:self action:@selector(doneAddingText) forControlEvents:UIControlEventTouchUpInside];
            [aDoneButton setBackgroundImage:IMAGE(@"AddButton") forState:UIControlStateNormal];
            [aDoneButton setFrame:CGRectMake(285, 15, 30, 30)];
            [self.inputView addSubview:aDoneButton];
            
            self.inputView.hidden = YES;
        } else {
            aCell.textLabel.font = FONT(@"HelveticaNeue", 17);
            
            UIButton *aTickButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [aTickButton setBackgroundImage:IMAGE(@"TickUnselected") forState:UIControlStateNormal];
            [aTickButton setBackgroundImage:IMAGE(@"TickSelected") forState:UIControlStateSelected];
            [aTickButton setFrame:CGRectMake(0, 0, 30, 30)];
            [aTickButton setUserInteractionEnabled:NO];
            aCell.accessoryView = aTickButton;
        }
    }
    
    if (theSection == 1) {
        NSDictionary *aStrategy = [[self strategies] objectAtIndex:theRow];
        NSString *aLocalizedLanguage = [Session language];
        NSString *aStrategyTitle = @"";
        
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aStrategyTitle = [aStrategy valueForKey:@"name"];
        } else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aStrategyTitle = [aStrategy valueForKey:@"name_es"];
        }

       // NSString *aStrategyTitle = [aStrategy valueForKey:@"name"];
        
        aStrategyTitle = [aStrategyTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aStrategyTitle = [aStrategyTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        aCell.textLabel.text = aStrategyTitle;
        
        NSString *aStrategyID = [aStrategy valueForKey:@"id"];
        if ([[self selectedStrategies] containsObject:aStrategyID]) {
            [(UIButton *)aCell.accessoryView setSelected:YES];
        } else {
            [(UIButton *)aCell.accessoryView setSelected:NO];
        }
    }
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    if (theSection == 0) {
        self.inputView.hidden = NO;
        [[self.inputView viewWithTag:kTextViewTag] becomeFirstResponder];
    } else {
        [self toggleStrategy:theRow];
    }
}


- (UIView *)tableView:(UITableView *)iTableView viewForHeaderInSection:(NSInteger)iSection {
    UILabel *aHeaderView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 30)];
    aHeaderView.font = FONT(@"HelveticaNeue", 14);
    
    if (iSection == 0) {
        aHeaderView.backgroundColor = RGBA_COLOR(254, 150, 140, 1);
        //aHeaderView.text = @"  Create your own strategy";
        aHeaderView.text = STLocalizedString(@"CreateStrategy", @"");
        aHeaderView.textColor = [UIColor whiteColor];
    } else {
        aHeaderView.backgroundColor = RGBA_COLOR(250, 230, 233, 1);
        //aHeaderView.text = @"  or select strategies from below.";
        aHeaderView.text = STLocalizedString(@"SelectStrategy", @"");
        aHeaderView.textColor = [UIColor grayColor];
    }
    
    return aHeaderView;
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 0;
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    if (theSection == 0) {
        aHeight = 60;
    } else if (theSection == 1) {
        NSDictionary *aStrategy = [[self strategies] objectAtIndex:theRow];
        NSString *aLocalizedLanguage = [Session language];
        NSString *aStrategyTitle = @"";
        
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aStrategyTitle = [aStrategy valueForKey:@"name"];
        } else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aStrategyTitle = [aStrategy valueForKey:@"name_es"];
        }

        
        //NSString *aStrategyTitle = [aStrategy valueForKey:@"name"];
        aStrategyTitle = [aStrategyTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aStrategyTitle = [aStrategyTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
       /* CGSize aSize = [aStrategyTitle sizeWithFont:FONT(@"HelveticaNeue", 17) constrainedToSize:CGSizeMake(280, MAXFLOAT)];*/
        CGSize maximumLabelSize = CGSizeMake(280,MAXFLOAT);
        CGRect textRect = [aStrategyTitle boundingRectWithSize:maximumLabelSize
                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:@{NSFontAttributeName:HELVETICA_NEUE(17)}
                                                  context:nil];
        CGSize expectedLabelSize = textRect.size;

        aHeight = (expectedLabelSize.height + 15);
    }
    
    return aHeight;
}


#pragma mark - Private

- (void)toggleStrategy:(NSInteger)iIndex {
    NSDictionary *aStrategy = [[self strategies] objectAtIndex:iIndex];
    NSString *aStrategyID = [aStrategy valueForKey:@"id"];
    if ([[self selectedStrategies] containsObject:aStrategyID]) {
        [[self selectedStrategies] removeObject:aStrategyID];
    } else {
        if ([[self selectedStrategies] count] < 3) {
            [[self selectedStrategies] addObject:aStrategyID];
        }
    }
    
    NSIndexPath *anIndexPath = [NSIndexPath indexPathForRow:iIndex inSection:1];
    [[self tableView] reloadRowsAtIndexPaths:[NSArray arrayWithObject:anIndexPath] withRowAnimation:UITableViewRowAnimationFade];
    
    [self toggleEvaluateOption];
}


- (void)toggleEvaluateOption {
    if (self.selectedStrategies.count == 3) {
        if (!self.evaluateButton) {
            self.evaluateButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [self.evaluateButton.titleLabel setFont:FONT(@"HelveticaNeue-Bold", 15)];
//            [self.evaluateButton setTitle:@"Evaluate Now" forState:UIControlStateNormal];
              [self.evaluateButton setTitle:STLocalizedString(@"EvaluateNow", @"") forState:UIControlStateNormal];
            [self.evaluateButton setBackgroundColor:[UIColor colorWithWhite:0 alpha:0.7]];
            [self.evaluateButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            self.evaluateButton.frame = CGRectMake(0, (self.view.bounds.size.height - 35), 320, 35);
            [self.evaluateButton addTarget:self action:@selector(evaluateStrategies) forControlEvents:UIControlEventTouchUpInside];
        }
        
        if (!self.evaluateButton.superview) {
            [self.view addSubview:self.evaluateButton];
        }
        
        self.evaluateButton.frame = CGRectMake(0, self.view.bounds.size.height, 320, 35);
        [UIView animateWithDuration:0.3 animations:^{
            self.evaluateButton.frame = CGRectMake(0, (self.view.bounds.size.height - 35), 320, 35);
        }];
    } else {
        if (self.evaluateButton && self.evaluateButton.superview) {
            self.evaluateButton.frame = CGRectMake(0, (self.view.bounds.size.height - 35), 320, 35);
            [UIView animateWithDuration:0.3 animations:^{
                self.evaluateButton.frame = CGRectMake(0, self.view.bounds.size.height, 320, 35);
            } completion:^(BOOL finished) {
                [self.evaluateButton removeFromSuperview];
            }];
        }
    }
}


- (void)evaluateStrategies {
    NSMutableArray *theStrategies = [NSMutableArray array];
    for (NSDictionary *aStrategy in [self strategies]) {
        NSString *anID = [aStrategy valueForKey:@"id"];
        if ([[self selectedStrategies] containsObject:anID]) {
            [theStrategies addObject:aStrategy];
        }
    }
    IPSEvaluateStrategy *anEvaluateStrategy = [[IPSEvaluateStrategy alloc] initWithStrategies:theStrategies];
    [[self navigationController] pushViewController:anEvaluateStrategy animated:YES];
}


- (void)doneAddingText {
    // NSString *aStrategyID = [NSString stringWithFormat:@"G_%lu", (unsigned long)[[self strategies] count]];
    UITextView *aTextView = (UITextView *)[self.inputView viewWithTag:kTextViewTag];
    NSString *aText = [aTextView text];
    [aTextView resignFirstResponder];
    self.inputView.hidden = YES;
    aTextView.text = @"";
    
    if (aText.length > 0) {
        /*
        NSMutableDictionary *aStrategy = [NSMutableDictionary dictionary];
        [aStrategy setObject:[self problemID] forKey:@"problem_id"];
        [aStrategy setObject:[self domainID] forKey:@"domain_id"];
        [aStrategy setObject:[self goalID] forKey:@"goal_id"];
        [aStrategy setObject:aStrategyID forKey:@"id"];
        [aStrategy setObject:aText forKey:@"name"];
        [[self strategies] addObject:aStrategy];
        
        [[self tableView] reloadData];
        [[self tableView] scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:(self.strategies.count - 1) inSection:1]
                                atScrollPosition:UITableViewScrollPositionTop animated:YES];
        
        [self saveStrategy:aStrategy];
         */
        
        NSMutableDictionary *aStrategy = [NSMutableDictionary dictionary];
        [aStrategy setObject:[self problemID] forKey:@"problem_id"];
        [aStrategy setObject:[self domainID] forKey:@"domain_id"];
        [aStrategy setObject:[self goalID] forKey:@"goal_id"];
        [aStrategy setObject:aText forKey:@"name_es"];
        [aStrategy setObject:aText forKey:@"name"];
        
        NSDictionary *aDetail = @{@"strategies": @[aStrategy]};
        NSDictionary *aPostDetail = @{@"user_data": [aDetail JSONRepresentation],
                                      @"user_id": [Session userID]};
        
        NSLog(@"aPostDetail: %@", aPostDetail);
        
        [self sendToServer:aPostDetail];

    }
}


- (void)sendToServer:(NSDictionary *)iDetail {
    [AppDelegate showLoading];
    
    NSString *anURLString = [NSString stringWithFormat:@"%@%@", BASE_URL, ADD_DATA_API];
    IPSURLHandler *anURLHandler = [[IPSURLHandler alloc] initWithURLString:anURLString];
    [anURLHandler sendRequestWithPost:iDetail];
    [anURLHandler setDelegate:self];
}


- (void)saveStrategy:(NSDictionary *)iStrategy {
    NSMutableArray *anAllStrategies = [NSMutableArray arrayWithArray:[[Session content] valueForKey:@"strategies"]];
    [anAllStrategies addObject:iStrategy];
    [[Session content] setObject:anAllStrategies forKey:@"strategies"];
    
    NSString *aPath  = [NSString stringWithFormat:@"%@/Content.plist", ApplicationSupport];
    [[Session content] writeToFile:aPath atomically:YES];
}


- (void)showTips {
    [[[UIAlertView alloc] initWithTitle:nil message:STLocalizedString(@"IPSStrategyController_ShowTips", @"") delegate:nil cancelButtonTitle:STLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil] show];
}


#pragma mark - IPSURLDelegate

- (void)urlHandler:(IPSURLHandler *)iHandler didFinishLoadingWithResponse:(id)iResponse {
    NSLog(@"iResponse: %@", iResponse);
    [AppDelegate removeLoading];
    
    if (iResponse && [iResponse isKindOfClass:[NSDictionary class]] && [iResponse valueForKey:@"data"]) {
        NSArray *anArray = [iResponse valueForKey:@"data"];
        if (anArray && anArray.count > 0) {
            NSDictionary *aStrategy = [anArray firstObject];
            if (aStrategy && aStrategy.count > 0) {
                [[self strategies] addObject:aStrategy];
                
                [[self tableView] reloadData];
                [[self tableView] scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:(self.strategies.count - 1) inSection:1]
                                        atScrollPosition:UITableViewScrollPositionTop animated:YES];
                
                [self saveStrategy:aStrategy];
            }
        }
    }
}


- (void)urlHandler:(IPSURLHandler *)iHandler didFailToLoadWithError:(NSError *)iError {
    NSLog(@"iError: %@", iError);
    [AppDelegate removeLoading];
}


#pragma mark - Orientation Method

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)iInterfaceOrientation {
    return (iInterfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@end
