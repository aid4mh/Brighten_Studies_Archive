//
//  IPSGoalController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 09/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSGoalController.h"
#import "IPSStrategyController.h"


#define kTextViewTag    1231


@interface IPSGoalController () <IPSURLDelegate>

@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) NSMutableArray *goals;
@property (nonatomic, retain) NSString *problemID;
@property (nonatomic, retain) UIView *inputView;

@end


@implementation IPSGoalController

@synthesize inputView;
@synthesize problemID;
@synthesize tableView;
@synthesize domainID;
@synthesize goals;

#pragma mark - Initialization

- (id)initWithProblem:(NSString *)iProblemID {
    self = [super init];
    if (self) {
        self.problemID = iProblemID;
        self.title = STLocalizedString(@"aChooseGoalTitle", @"");
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
    self.inputView = nil;
    self.problemID = nil;
    self.tableView = nil;
    self.domainID = nil;
    self.goals = nil;
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:IMAGE(@"TipButton") style:UIBarButtonItemStylePlain target:self action:@selector(showTips)];
    
    self.goals = [NSMutableArray array];
    for (NSDictionary *aGoal in [[Session content] valueForKey:@"goals"]) {
        if ([[aGoal valueForKey:@"problem_id"] isEqualToString:self.problemID]) {
            [[self goals] addObject:aGoal];
        }
    }
    
    CGRect aFrame = self.view.bounds;
    if (!IS_iOS7) {
        aFrame.size.height -= 44;
    }
    self.tableView = [[UITableView alloc] initWithFrame:aFrame];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 2;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = 1;
    if (iSection == 1) {
        aRowCount = self.goals.count;
    }
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.textColor = [UIColor blackColor];
        aCell.textLabel.numberOfLines = 0;
        
        if (theSection == 0) {
            UIImageView *aPenView = [[UIImageView alloc] initWithImage:IMAGE(@"PenIcon")];
            [aPenView setFrame:CGRectMake(6, 0, 30, 30)];
            [aCell addSubview:aPenView];
            
            aCell.textLabel.textColor = [UIColor grayColor];
            aCell.textLabel.font = FONT(@"HelveticaNeue", 14);
           // aCell.textLabel.text = @"     Add your own goal.\n\n\n";
            aCell.textLabel.text = STLocalizedString(@"AddGoal", @"");
            
            self.inputView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 60)];
            self.inputView.backgroundColor = [UIColor whiteColor];
            [aCell addSubview:self.inputView];
            
            UITextView *aTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, 280, 60)];
            aTextView.backgroundColor = [UIColor whiteColor];
            aTextView.font = FONT(@"HelveticaNeue", 14);
            [self.inputView addSubview:aTextView];
            aTextView.tag = kTextViewTag;
            
            UIButton *aDoneButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [aDoneButton addTarget:self action:@selector(doneAddingText) forControlEvents:UIControlEventTouchUpInside];
            [aDoneButton setBackgroundImage:IMAGE(@"AddButton") forState:UIControlStateNormal];
            [aDoneButton setFrame:CGRectMake(285, 15, 30, 30)];
            [self.inputView addSubview:aDoneButton];
            
            self.inputView.hidden = YES;
        } else {
            aCell.textLabel.font = FONT(@"HelveticaNeue", 17);
            aCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
    }
    
    if (theSection == 1) {
        NSDictionary *aGoal = [[self goals] objectAtIndex:theRow];
        NSString *aLocalizedLanguage = [Session language];
        NSString *aGoalTitle = @"";
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aGoalTitle = [aGoal valueForKey:@"name"];
        }else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aGoalTitle = [aGoal valueForKey:@"name_es"];
        }

        aGoalTitle = [aGoalTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aGoalTitle = [aGoalTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        aCell.textLabel.text = aGoalTitle;
    }
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    if (theSection == 0) {
        self.inputView.hidden = NO;
        [[self.inputView viewWithTag:kTextViewTag] becomeFirstResponder];
    } else {
        NSDictionary *aGoal = [[self goals] objectAtIndex:theRow];
        NSString *aGoalID = [aGoal valueForKey:@"id"];
        
        [[Session selections] setObject:[aGoal valueForKey:@"name"] forKey:@"Goal"];
        IPSStrategyController *aStrategyController = [[IPSStrategyController alloc] initWithGoal:aGoalID];
        [[self navigationController] pushViewController:aStrategyController animated:YES];
        [aStrategyController setProblemID:[self problemID]];
        [aStrategyController setDomainID:[self domainID]];
    }
}


- (UIView *)tableView:(UITableView *)iTableView viewForHeaderInSection:(NSInteger)iSection {
    UILabel *aHeaderView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 30)];
    aHeaderView.font = FONT(@"HelveticaNeue", 14);
    
    if (iSection == 0) {
        aHeaderView.backgroundColor = RGBA_COLOR(254, 150, 140, 1);
        //aHeaderView.text = @"  Create your own goal";
        aHeaderView.text = STLocalizedString(@"CreateGoal", @"");
        aHeaderView.textColor = [UIColor whiteColor];
    } else {
        aHeaderView.backgroundColor = RGBA_COLOR(250, 230, 233, 1);
        //aHeaderView.text = @"  or select a goal from below.";
        aHeaderView.text = STLocalizedString(@"SelectGoal", @"");
        aHeaderView.textColor = [UIColor grayColor];
    }
    
    return aHeaderView;
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 0;
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    if (theSection == 0) {
        aHeight = 60;
    } else if (theSection == 1) {
        NSDictionary *aGoal = [[self goals] objectAtIndex:theRow];
        NSString *aGoalTitle = [[Session language] isEqualToString:@"en"] ? [aGoal valueForKey:@"name"] : [aGoal valueForKey:@"name_es"];
        aGoalTitle = [aGoalTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aGoalTitle = [aGoalTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
      /*  CGSize aSize = [aGoalTitle sizeWithFont:FONT(@"HelveticaNeue", 17) constrainedToSize:CGSizeMake(270, MAXFLOAT)];*/
        CGSize maximumLabelSize = CGSizeMake(270,MAXFLOAT);
        CGRect textRect = [aGoalTitle boundingRectWithSize:maximumLabelSize
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                            attributes:@{NSFontAttributeName:HELVETICA_NEUE(17)}
                                               context:nil];
        CGSize expectedLabelSize = textRect.size;
        aHeight = (expectedLabelSize.height + 15);
    }
    
    return aHeight;
}


#pragma mark - Private

- (void)doneAddingText {
    // NSString *aGoalID = [NSString stringWithFormat:@"G_%lu", (unsigned long)[[self goals] count]];
    UITextView *aTextView = (UITextView *)[self.inputView viewWithTag:kTextViewTag];
    NSString *aText = [aTextView text];
    [aTextView resignFirstResponder];
    self.inputView.hidden = YES;
    aTextView.text = @"";
    
    if (aText.length > 0) {
        /*
        NSMutableDictionary *aGoal = [NSMutableDictionary dictionary];
        [aGoal setObject:[self problemID] forKey:@"problem_id"];
        [aGoal setObject:[self domainID] forKey:@"domain_id"];
        [aGoal setObject:aGoalID forKey:@"id"];
        [aGoal setObject:aText forKey:@"name"];
        [[self goals] addObject:aGoal];
        
        [[self tableView] reloadData];
        [[self tableView] scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:(self.goals.count - 1) inSection:1]
                                atScrollPosition:UITableViewScrollPositionTop animated:YES];
        
        [self saveGoal:aGoal];
         */
        
        NSMutableDictionary *aGoal = [NSMutableDictionary dictionary];
        [aGoal setObject:[self problemID] forKey:@"problem_id"];
        [aGoal setObject:[self domainID] forKey:@"domain_id"];
        [aGoal setObject:aText forKey:@"name_es"];
        [aGoal setObject:aText forKey:@"name"];
        
        NSDictionary *aDetail = @{@"goals": @[aGoal]};
        NSDictionary *aPostDetail = @{@"user_data": [aDetail JSONRepresentation],
                                      @"user_id": [Session userID]};
        
        NSLog(@"aPostDetail: %@", aPostDetail);
        
        [self sendToServer:aPostDetail];
    }
}


- (void)sendToServer:(NSDictionary *)iDetail {
    [AppDelegate showLoading];
    
    NSString *anURLString = [NSString stringWithFormat:@"%@%@", BASE_URL, ADD_DATA_API];
    IPSURLHandler *anURLHandler = [[IPSURLHandler alloc] initWithURLString:anURLString];
    [anURLHandler sendRequestWithPost:iDetail];
    [anURLHandler setDelegate:self];
}


- (void)saveGoal:(NSDictionary *)iGoal {
    NSMutableArray *anAllGoals = [NSMutableArray arrayWithArray:[[Session content] valueForKey:@"goals"]];
    [anAllGoals addObject:iGoal];
    [[Session content] setObject:anAllGoals forKey:@"goals"];
    NSString *aPath  = [NSString stringWithFormat:@"%@/Content.plist", ApplicationSupport];
    [[Session content] writeToFile:aPath atomically:YES];
}


- (void)showTips {
     [[[UIAlertView alloc] initWithTitle:nil message:STLocalizedString(@"aPickGoalMsg", @"") delegate:nil cancelButtonTitle:STLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil] show];
}


#pragma mark - IPSURLDelegate

- (void)urlHandler:(IPSURLHandler *)iHandler didFinishLoadingWithResponse:(id)iResponse {
    NSLog(@"iResponse: %@", iResponse);
    [AppDelegate removeLoading];
    
    if (iResponse && [iResponse valueForKey:@"data"]) {
        NSArray *anArray = [iResponse valueForKey:@"data"];
        if (anArray && anArray.count > 0) {
            NSDictionary *aGoal = [anArray firstObject];
            if (aGoal && aGoal.count > 0) {
                [[self goals] addObject:aGoal];
                
                [[self tableView] reloadData];
                [[self tableView] scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:(self.goals.count - 1) inSection:1]
                                        atScrollPosition:UITableViewScrollPositionTop animated:YES];
                
                [self saveGoal:aGoal];
            }
        }
    }
}


- (void)urlHandler:(IPSURLHandler *)iHandler didFailToLoadWithError:(NSError *)iError {
    NSLog(@"iError: %@", iError);
    [AppDelegate removeLoading];
}


#pragma mark - Orientation Method

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)iInterfaceOrientation {
    return (iInterfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@end
