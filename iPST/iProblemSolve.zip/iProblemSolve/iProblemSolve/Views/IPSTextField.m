//
//  IPSTextField.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 22/02/14.
//  Copyright (c) 2014 Wow Labz. All rights reserved.
//


#import "IPSTextField.h"


@interface IPSTextField ()

@property (nonatomic, assign) UIEdgeInsets edgeInsets;

@end


@implementation IPSTextField

@synthesize edgeInsets;

#pragma mark - Initialization

- (id)initWithFrame:(CGRect)iFrame{
    self = [super initWithFrame:iFrame];
    if (self) {
        self.edgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    }
    return self;
}


- (id)initWithCoder:(NSCoder *)iDecoder{
    self = [super initWithCoder:iDecoder];
    if(self){
        self.edgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    }
    return self;
}


#pragma mark -

- (CGRect)textRectForBounds:(CGRect)iBounds {
    return [super textRectForBounds:UIEdgeInsetsInsetRect(iBounds, self.edgeInsets)];
}


- (CGRect)editingRectForBounds:(CGRect)iBounds {
    return [super editingRectForBounds:UIEdgeInsetsInsetRect(iBounds, self.edgeInsets)];
}

@end
