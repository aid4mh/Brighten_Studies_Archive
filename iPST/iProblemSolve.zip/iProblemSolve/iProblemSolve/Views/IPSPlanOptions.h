//
//  IPSPlanOptions.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import <UIKit/UIKit.h>

@protocol IPSOptionsDelegate;

@interface IPSPlanOptions : UIView <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, assign) id<IPSOptionsDelegate> delegate;

@end


@protocol IPSOptionsDelegate <NSObject>

- (void)deletePlan;
- (void)reschedulePlan;

@end