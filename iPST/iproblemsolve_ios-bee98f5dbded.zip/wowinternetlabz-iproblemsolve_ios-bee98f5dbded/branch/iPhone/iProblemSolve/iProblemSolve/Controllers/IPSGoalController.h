//
//  IPSGoalController.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 09/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface IPSGoalController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) NSString *domainID;

- (id)initWithProblem:(NSString *)iProblemID;

@end
