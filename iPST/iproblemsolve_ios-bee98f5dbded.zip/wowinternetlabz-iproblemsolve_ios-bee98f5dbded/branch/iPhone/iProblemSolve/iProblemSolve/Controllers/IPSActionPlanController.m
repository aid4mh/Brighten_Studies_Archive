//
//  IPSActionPlanController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSActionPlanController.h"
#import "IPSProblemController.h"
#import "IPSLoadingView.h"


#define kTextViewTag    1231

@interface IPSActionPlanController ()

@property (nonatomic, retain) UIView *inputView;
@property (nonatomic, retain) NSString *strategyID;
@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) NSDictionary *strategy;
@property (nonatomic, retain) NSMutableArray *actionPlans;
@property (nonatomic, retain) NSDictionary *plannedAction;
@property (nonatomic, retain) IPSLoadingView *loadingView;

@end


@implementation IPSActionPlanController

@synthesize strategy;
@synthesize tableView;
@synthesize inputView;
@synthesize strategyID;
@synthesize actionPlans;
@synthesize loadingView;
@synthesize plannedAction;


#pragma mark - Initialization

- (id)initWithStrategy:(NSDictionary *)iStrategy {
    self = [super init];
    if (self) {
        self.strategy = iStrategy;
        //self.title = @"Create Action Plan";
        self.title = STLocalizedString(@"CreateActionPlan", @"");
        self.strategyID = [iStrategy valueForKey:@"id"];
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
    self.strategy = nil;
    self.tableView = nil;
    self.inputView = nil;
    self.strategyID = nil;
    self.actionPlans = nil;
    self.plannedAction = nil;
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:IMAGE(@"TipButton") style:UIBarButtonItemStylePlain target:self action:@selector(showTips)];
    
    self.actionPlans = [NSMutableArray array];
    for (NSDictionary *anActionPlan in [[Session content] valueForKey:@"actionplan"]) {
        if ([[anActionPlan valueForKey:@"strategy_id"] isEqualToString:self.strategyID]) {
            [[self actionPlans] addObject:anActionPlan];
        }
    }
    
    CGRect aFrame = self.view.bounds;
    if (!IS_iOS7) {
        aFrame.size.height -= 44;
    }
    self.tableView = [[UITableView alloc] initWithFrame:aFrame];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIFont *aFont = FONT(@"HelveticaNeue", 14);
    NSString *aStrategy = @"";
    NSString *aLocalizedLanguage = [Session language];
    if ([aLocalizedLanguage isEqualToString:@"en"] ) {
        aStrategy = [[self strategy] valueForKey:@"name"];
    } else if ([aLocalizedLanguage isEqualToString:@"es"]){
        aStrategy = [[self strategy] valueForKey:@"name_es"];
    }
    
    
   /* CGSize aSize = [aStrategy sizeWithFont:aFont constrainedToSize:CGSizeMake(300, MAXFLOAT)];*/
    CGSize maximumLabelSize = CGSizeMake(300,MAXFLOAT);
    CGRect textRect = [aStrategy boundingRectWithSize:maximumLabelSize
                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:@{NSFontAttributeName:aFont}
                                                  context:nil];
    CGSize expectedLabelSize = textRect.size;
    UIView *aHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, (expectedLabelSize.height + 20 + 20))];
    [aHeaderView setBackgroundColor:[UIColor whiteColor]];
    
    UILabel *aHeaderLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 300, 20)];
    [aHeaderLabel setText:STLocalizedString(@"StrategyToUse", @"")];
    [aHeaderLabel setBackgroundColor:[UIColor clearColor]];
    [aHeaderLabel setFont:FONT(@"HelveticaNeue", 13)];
    [aHeaderLabel setTextColor:[UIColor grayColor]];
    [aHeaderView addSubview:aHeaderLabel];
    
    UILabel *aStrategyLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 25, 300, (expectedLabelSize.height + 10))];
    [aStrategyLabel setBackgroundColor:[UIColor clearColor]];
    [aStrategyLabel setFont:FONT(@"HelveticaNeue", 14)];
    [aStrategyLabel setTextColor:[UIColor blackColor]];
    [aHeaderView addSubview:aStrategyLabel];
    [aStrategyLabel setNumberOfLines:0];
    [aStrategyLabel setText:aStrategy];
    
    [[self tableView] setTableHeaderView:aHeaderView];
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 2;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = 1;
    if (iSection == 1) {
        aRowCount = self.actionPlans.count;
    }
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.textColor = [UIColor blackColor];
        aCell.textLabel.numberOfLines = 0;
        
        if (theSection == 0) {
            UIImageView *aPenView = [[UIImageView alloc] initWithImage:IMAGE(@"PenIcon")];
            [aPenView setFrame:CGRectMake(6, 0, 30, 30)];
            [aCell addSubview:aPenView];
            
            aCell.textLabel.textColor = [UIColor grayColor];
            aCell.textLabel.font = FONT(@"HelveticaNeue", 14);
         //   aCell.textLabel.text = @"     Write your action plan.\n\n\n";
            aCell.textLabel.text = STLocalizedString(@"WriteYourAction", @"");
            
            self.inputView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 60)];
            self.inputView.backgroundColor = [UIColor whiteColor];
            [aCell addSubview:self.inputView];
            
            UITextView *aTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, 280, 60)];
            aTextView.backgroundColor = [UIColor whiteColor];
            aTextView.font = FONT(@"HelveticaNeue", 14);
            [self.inputView addSubview:aTextView];
            aTextView.tag = kTextViewTag;
            
            UIButton *aDoneButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [aDoneButton addTarget:self action:@selector(doneAddingText) forControlEvents:UIControlEventTouchUpInside];
            [aDoneButton setBackgroundImage:IMAGE(@"AddButton") forState:UIControlStateNormal];
            [aDoneButton setFrame:CGRectMake(285, 15, 30, 30)];
            [self.inputView addSubview:aDoneButton];
            
            self.inputView.hidden = YES;
        } else {
            aCell.textLabel.font = FONT(@"HelveticaNeue", 17);
            
            UIButton *aTickButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [aTickButton setBackgroundImage:IMAGE(@"CalendarIcon") forState:UIControlStateNormal];
            [aTickButton setFrame:CGRectMake(0, 0, 30, 30)];
            [aTickButton setUserInteractionEnabled:NO];
            aCell.accessoryView = aTickButton;
        }
    }
    
    if (theSection == 1) {
        NSDictionary *anActionPlan = [[self actionPlans] objectAtIndex:theRow];
        NSString *aLocalizedLanguage = [Session language];
        NSString *aDescription = @"";
        
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aDescription = [anActionPlan valueForKey:@"name"];
        }else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aDescription = [anActionPlan valueForKey:@"name_es"];
        }
        
        aDescription = [aDescription stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aDescription = [aDescription stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        aCell.textLabel.text = aDescription;
    }
    
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    if (theSection == 0) {
        self.inputView.hidden = NO;
        [[self.inputView viewWithTag:kTextViewTag] becomeFirstResponder];
    } else {
        self.plannedAction = [[self actionPlans] objectAtIndex:theRow];
        [self addToCalendar];
    }
}


- (UIView *)tableView:(UITableView *)iTableView viewForHeaderInSection:(NSInteger)iSection {
    UILabel *aHeaderView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 30)];
    aHeaderView.font = FONT(@"HelveticaNeue", 14);
    
    if (iSection == 0) {
        aHeaderView.backgroundColor = RGBA_COLOR(254, 150, 140, 1);
        aHeaderView.text = STLocalizedString(@"CreateYourAction", @"");
        aHeaderView.textColor = [UIColor whiteColor];
    } else {
        aHeaderView.backgroundColor = RGBA_COLOR(250, 230, 233, 1);
        aHeaderView.text = STLocalizedString(@"SelectActionPlans", @"");
        aHeaderView.textColor = [UIColor grayColor];
    }
    
    return aHeaderView;
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 0;
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    if (theSection == 0) {
        aHeight = 60;
    } else if (theSection == 1) {
        NSDictionary *anActionPlan = [[self actionPlans] objectAtIndex:theRow];
        NSString *aTitle = [[Session language] isEqualToString:@"en"] ? [anActionPlan valueForKey:@"name"] : [anActionPlan valueForKey:@"name_es"];
        aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        /*CGSize aSize = [aTitle sizeWithFont:FONT(@"HelveticaNeue", 17) constrainedToSize:CGSizeMake(260, MAXFLOAT)];*/
        CGSize maximumLabelSize = CGSizeMake(260,MAXFLOAT);
        CGRect textRect = [aTitle boundingRectWithSize:maximumLabelSize
                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:@{NSFontAttributeName:HELVETICA_NEUE(17)}
                                                  context:nil];
        CGSize expectedLabelSize = textRect.size;

        aHeight = (expectedLabelSize.height + 15);
    }
    
    return aHeight;
}


#pragma mark - Private

- (void)doneAddingText {
    NSString *aActionID = [NSString stringWithFormat:@"G_%lu", (unsigned long)[[self actionPlans] count]];
    UITextView *aTextView = (UITextView *)[self.inputView viewWithTag:kTextViewTag];
    NSString *aText = [aTextView text];
    [aTextView resignFirstResponder];
    self.inputView.hidden = YES;
    aTextView.text = @"";
    
    if (aText.length > 0) {
        NSString *aProblemID = [[self strategy] valueForKey:@"problem_id"];
        NSString *aDomainID = [[self strategy] valueForKey:@"domain_id"];
        NSString *aGoalID = [[self strategy] valueForKey:@"goal_id"];
        
        NSMutableDictionary *anActionPlan = [NSMutableDictionary dictionary];
        [anActionPlan setObject:[self strategyID] forKey:@"strategy_id"];
        [anActionPlan setObject:aProblemID forKey:@"problem_id"];
        [anActionPlan setObject:aDomainID forKey:@"domain_id"];
        [anActionPlan setObject:aGoalID forKey:@"goal_id"];
        [anActionPlan setObject:aActionID forKey:@"id"];
        [anActionPlan setObject:aText forKey:@"name"];
        [[self actionPlans] addObject:anActionPlan];
        
        [[self tableView] reloadData];
        [[self tableView] scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:(self.actionPlans.count - 1) inSection:1]
                                atScrollPosition:UITableViewScrollPositionTop animated:YES];
        
        [self saveActionPlan:anActionPlan];
    }
}


- (void)saveActionPlan:(NSDictionary *)iActionPlan {
    NSMutableArray *anAllActionPlans = [NSMutableArray arrayWithArray:[[Session content] valueForKey:@"actionplan"]];
    [anAllActionPlans addObject:iActionPlan];
    [[Session content] setObject:anAllActionPlans forKey:@"actionplan"];
    NSString *aPath  = [NSString stringWithFormat:@"%@/Content.plist", ApplicationSupport];
    [[Session content] writeToFile:aPath atomically:YES];
}


- (void)addToCalendar {
    if (self.plannedAction) {
        EKEventStore *aStore = [[EKEventStore alloc] init];
        
        if([aStore respondsToSelector:@selector(requestAccessToEntityType:completion:)]) {
            // iOS 6
            [aStore requestAccessToEntityType:EKEntityTypeEvent
                                   completion:^(BOOL iGranted, NSError *iError) {
                                       if (iGranted) {
                                           dispatch_async(dispatch_get_main_queue(), ^{
                                               [self createEventAndPresentViewController:aStore];
                                           });
                                       }
                                   }];
        } else {
            // iOS 5
            [self createEventAndPresentViewController:aStore];
        }
    }
}


- (void)createEventAndPresentViewController:(EKEventStore *)iStore {
    EKEvent *anEvent = [self findOrCreateEvent:iStore];
    
    EKEventEditViewController *anEventController = [[EKEventEditViewController alloc] init];
    anEventController.event = anEvent;
    anEventController.eventStore = iStore;
    anEventController.editViewDelegate = self;
    
    [self presentViewController:anEventController animated:YES completion:nil];
}


- (EKEvent *)findOrCreateEvent:(EKEventStore *)iStore {
    NSString *aTitle = @"";
    NSString *aLocalizedLanguage = [Session language];
    if ([aLocalizedLanguage isEqualToString:@"en"] ) {
        aTitle = [[self plannedAction] valueForKey:@"name"];
    } else if ([aLocalizedLanguage isEqualToString:@"es"]){
        aTitle = [[self plannedAction] valueForKey:@"name_es"];
    }

    aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    aTitle = [aTitle stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    EKEvent *anEvent = [self findEventWithTitle:aTitle inEventStore:iStore];
    
    if (!anEvent) {
        anEvent = [EKEvent eventWithEventStore:iStore];
        
        // Next Date
        NSCalendarUnit aDateUnits = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
        NSDateComponents *aDateComponents = [[NSCalendar currentCalendar] components:aDateUnits fromDate:[NSDate date]];
        aDateComponents.day = (aDateComponents.day + 1);
        NSDate *aNextDate = [[NSCalendar currentCalendar] dateFromComponents:aDateComponents];
        
        EKAlarm *anAlarm =  [EKAlarm alarmWithRelativeOffset:36000]; // 10:00 AM
        NSString *aLocalizedLanguage = [Session language];
        NSString *aStrategy = @"";
        
        if ([aLocalizedLanguage isEqualToString:@"en"] ) {
            aStrategy =[[self strategy] valueForKey:@"name"];
        } else if ([aLocalizedLanguage isEqualToString:@"es"]){
            aStrategy = [[self strategy] valueForKey:@"name_es"];
        }

       // NSString *aStrategy = [[self strategy] valueForKey:@"name"];
        aStrategy = [aStrategy stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        aStrategy = [aStrategy stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        anEvent.allDay = YES;
        anEvent.title = aTitle;
        [anEvent addAlarm:anAlarm];
        anEvent.endDate = aNextDate;
        anEvent.startDate = aNextDate;
        anEvent.calendar = [iStore defaultCalendarForNewEvents];
       // anEvent.notes = [NSString stringWithFormat:@"Strategy: %@", aStrategy];
        anEvent.notes = [NSString stringWithFormat:STLocalizedString(@"Strategy: %@", @""), aStrategy];

    }
    
    return anEvent;
}


- (EKEvent *)findEventWithTitle:(NSString *)iTitle inEventStore:(EKEventStore *)iStore {
    // Get the appropriate calendar
    NSCalendar *aCalendar = [NSCalendar currentCalendar];
    
    // Create the start range date components
    NSDateComponents *anOneDayAgoComponents = [[NSDateComponents alloc] init];
    anOneDayAgoComponents.day = -1;
    NSDate *oneDayAgo = [aCalendar dateByAddingComponents:anOneDayAgoComponents
                                                   toDate:[NSDate date]
                                                  options:0];
    
    // Create the end range date components
    NSDateComponents *anOneWeekFromNowComponents = [[NSDateComponents alloc] init];
    anOneWeekFromNowComponents.day = 120;
    NSDate *oneWeekFromNow = [aCalendar dateByAddingComponents:anOneWeekFromNowComponents
                                                        toDate:[NSDate date]
                                                       options:0];
    
    // Create the predicate from the event store's instance method
    NSPredicate *aPredicate = [iStore predicateForEventsWithStartDate:oneDayAgo
                                                              endDate:oneWeekFromNow
                                                            calendars:nil];
    
    // Fetch all events that match the predicate
    NSArray *anAllEvents = [iStore eventsMatchingPredicate:aPredicate];
    
    for (EKEvent *anEvent in anAllEvents) {
        if ([iTitle isEqualToString:anEvent.title]) {
            return anEvent;
        }
    }
    
    return nil;
}


- (void)goHome {
    [[self navigationController] popToRootViewControllerAnimated:YES];
}


- (void)showTips {
     [[[UIAlertView alloc] initWithTitle:nil message:STLocalizedString(@"IPSActionPlanController_ShowTips", @"") delegate:nil cancelButtonTitle:STLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil] show];
}


- (void)saveProgress:(NSMutableDictionary *)iProgress {
    NSData *aResponseData = nil;
    NSURLResponse *anURLResponse = nil;
    NSString *aPostDetail = [iProgress JSONRepresentation];
    NSString *anURLString = @"https://pulvinar.cin.ucsf.edu/datamart/Brighten/api/v1/add_pst";
    IPSURLHandler *anURLHandler = [[IPSURLHandler alloc] initWithURLString:anURLString];
    aResponseData = [anURLHandler getResponseForPostBody:aPostDetail withResponse:&anURLResponse];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self gameDetailResponse:anURLResponse];
    });
}


- (void)gameDetailResponse:(NSURLResponse *)iResponse {
    NSInteger aStatusCode = [(NSHTTPURLResponse *)iResponse statusCode];
    if (aStatusCode == 200) {
        [[Session userActivity] removeAllObjects];
    }
    
    NSUserDefaults *anUserDefault = [NSUserDefaults standardUserDefaults];
    [anUserDefault setObject:[Session userActivity] forKey:USER_ACTIVITY];
    
    [self continueSession];
}


- (void)continueSession {
    [self.loadingView removeFromSuperview];
    self.loadingView = nil;
    [[[UIAlertView alloc] initWithTitle:STLocalizedString(@"GreatJob", @"") message:STLocalizedString(@"IPSActionPlanController_continueSession", @"") delegate:self cancelButtonTitle:STLocalizedString(@"HomeScreen", @"") otherButtonTitles:STLocalizedString(@"AddActionPlan", @""), STLocalizedString(@"Solve Another Problem", @""), nil] show];
}


#pragma mark - EKEventEditViewDelegate

- (void)eventEditViewController:(EKEventEditViewController *)iController didCompleteWithAction:(EKEventEditViewAction)iAction {
    [self dismissViewControllerAnimated:YES completion:^{
        if (iAction == EKEventEditViewActionSaved) {
            if (![Session actionPlans]) {
                [Session setActionPlans:[NSMutableArray array]];
            }
            
            BOOL isAvailable = NO;
            for (NSDictionary *anActionPlan in [Session actionPlans]) {
                if ([[anActionPlan valueForKey:@"id"] isEqualToString:[[self plannedAction] valueForKey:@"id"]]) {
                    isAvailable = YES;
                    break;
                }
            }
            
            if (!isAvailable) {
                [[Session actionPlans] addObject:[self plannedAction]];
                [Session updateActionPlan];
            }
            
            NSMutableDictionary *aSelection = [NSMutableDictionary dictionaryWithDictionary:[Session selections]];
            [aSelection setObject:[[self plannedAction] valueForKey:@"name"] forKey:@"Action Plan"];
            [[Session userActivity] addObject:aSelection];
            
            NSDictionary *anUserSelection = @{@"submitted": [Session UTCDateString],
                                              @"user": @{@"id": [Session userID]},
                                              @"data": [Session userActivity]};
            
            dispatch_async(dispatch_get_main_queue(), ^{
                self.loadingView = [[IPSLoadingView alloc] initWithFrame:AppDelegate.window.bounds message:@"Saving data..." showProgress:NO];
                [AppDelegate.window addSubview:self.loadingView];
            });
            
            NSLog(@"DATA \n%@", anUserSelection);
            [self performSelectorInBackground:@selector(saveProgress:) withObject:anUserSelection];
        }
    }];
}


#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)iAlertView clickedButtonAtIndex:(NSInteger)iButtonIndex {
    if (iButtonIndex == 0) {
        [[self navigationController] popToRootViewControllerAnimated:YES];
    } else if (iButtonIndex == 1) {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:STLocalizedString(@"Home", @"") style:UIBarButtonItemStyleDone target:self action:@selector(goHome)];

    } else if (iButtonIndex == 2) {
        for (UIViewController *aController in [[self navigationController] viewControllers]) {
            if ([aController isKindOfClass:[IPSProblemController class]]) {
                [[self navigationController] popToViewController:aController animated:YES];
                break;
            }
        }
    }
}


#pragma mark - Orientation Method

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)iInterfaceOrientation {
    return (iInterfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


@end
