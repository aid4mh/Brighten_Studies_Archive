//
//  IPSMoodController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 14/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSMoodController.h"
#import "GraphDataObject.h"
#import "GraphView.h"


@interface IPSMoodController ()

@end


@implementation IPSMoodController


#pragma mark - Initialization

- (id)init {
    self = [super init];
    if (self) {
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    CGFloat aWidth = (IS_IPHONE5) ? 568 : 480;
    SET_LANDSCAPE(self.view, CGRectMake(0, 0, aWidth, 320));
    
    NSMutableArray *aMoodDetails = [NSMutableArray array];
    for (NSDictionary *aMood in [Session moods]) {
        GraphDataObject *aMoodObject = [[GraphDataObject alloc] init];
        aMoodObject.value = [aMood valueForKey:@"Mood"];
        aMoodObject.time = [aMood valueForKey:@"Date"];
        [aMoodDetails addObject:aMoodObject];
    }
    
    NSCalendarUnit aDateUnits = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
    
    NSDateComponents *aStartDateComponents = [[NSCalendar currentCalendar] components:aDateUnits fromDate:[[[Session moods] firstObject] valueForKey:@"Date"]];
    aStartDateComponents.day = (aStartDateComponents.day - 1);
    NSDate *aStartDate = [[NSCalendar currentCalendar] dateFromComponents:aStartDateComponents];

    NSDateComponents *anEndDateComponents = [[NSCalendar currentCalendar] components:aDateUnits fromDate:[[[Session moods] lastObject] valueForKey:@"Date"]];
    anEndDateComponents.day = (anEndDateComponents.day + 1);
    NSDate *anEndDate = [[NSCalendar currentCalendar] dateFromComponents:anEndDateComponents];
    
    CGFloat aGraphWidth = (IS_IPHONE5) ? 554 : 466;
    GraphView *aGraphView = [[GraphView alloc] initWithFrame:CGRectMake(7, 67, aGraphWidth, 206) objectsArray:aMoodDetails
                                                   startDate:aStartDate endDate:anEndDate delegate:nil];
    aGraphView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:aGraphView];
    
    CGFloat aXOffset = (IS_IPHONE5) ? 520 : 440;
    UIButton *aCloseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [aCloseButton addTarget:self action:@selector(dismissChart) forControlEvents:UIControlEventTouchUpInside];
    [aCloseButton setBackgroundImage:IMAGE(@"Close") forState:UIControlStateNormal];
    [aCloseButton setFrame:CGRectMake(aXOffset, 20, 30, 30)];
    [self.view addSubview:aCloseButton];
}


#pragma mark - Private

- (void)dismissChart {
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - Orientation Method

- (BOOL)shouldAutorotate {
    return NO;
}


- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscapeLeft;
}


-  (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationLandscapeLeft;
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@end
