//
//  IPSProblemController.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 25/11/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSProblemView.h"
#import "IPSProblemController.h"


@interface IPSProblemController ()

@property (nonatomic, retain) UITableView *tableView;

@end


@implementation IPSProblemController

@synthesize tableView;

#pragma mark - Initialization

- (id)init {
    self = [super init];
    if (self) {
       // self.title = @"Problem Solving";
        self.title = STLocalizedString(@"ProblemSolving", @"");
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
    self.tableView = nil;
}


#pragma mark - View Lifecycle

- (void)loadView {
    [super loadView];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = YES;
    }
    
    SET_BACKGROUND(self.view, self.view.bounds);
    self.navigationController.navigationBarHidden = NO;
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:IMAGE(@"TipButton") style:UIBarButtonItemStylePlain target:self action:@selector(showTips)];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"CONTENT: %@", [Session content]);
    
    UILabel *aTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    aTitleLabel.text = STLocalizedString(@"PickAreaTitle", @"");
    aTitleLabel.backgroundColor = [UIColor clearColor];
    aTitleLabel.font = FONT(@"HelveticaNeue", 17);
    aTitleLabel.textColor = [UIColor whiteColor];
    
    NSInteger aRowCount = [[[Session content] valueForKey:@"domain"] count];
    
    CGFloat aHeight = ((aRowCount * 50) + 55);
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, aHeight)];
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorColor = [UIColor whiteColor];
    self.tableView.tableHeaderView = aTitleLabel;
    [self.view addSubview:self.tableView];
    self.tableView.scrollEnabled = NO;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}


- (void)viewWillAppear:(BOOL)iAnimated {
    [super viewWillAppear:iAnimated];
    self.navigationController.navigationBarHidden = NO;
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)iTableView {
    NSInteger aSectionCount = 1;
    return aSectionCount;
}


- (NSInteger)tableView:(UITableView *)iTableView numberOfRowsInSection:(NSInteger)iSection {
    NSInteger aRowCount = [[[Session content] valueForKey:@"domain"] count];
    return aRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)iTableView cellForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    NSInteger theRow = iIndexPath.row;
    NSInteger theSection = iIndexPath.section;
    
    NSString *aCellIdentifier = [NSString stringWithFormat:@"Cell-%ld-%ld-%ld", (long)theSection, (long)theRow, (long)iTableView.tag];
    UITableViewCell *aCell = (UITableViewCell *)[iTableView dequeueReusableCellWithIdentifier:aCellIdentifier];
    if (aCell == nil) {
        aCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:aCellIdentifier];
        aCell.textLabel.font = FONT(@"HelveticaNeue-CondensedBold", 25);
        aCell.selectionStyle = UITableViewCellSelectionStyleGray;
        aCell.textLabel.textColor = [UIColor whiteColor];
        aCell.backgroundColor = [UIColor clearColor];
    }
    NSDictionary *aDomain = [[[Session content] valueForKey:@"domain"] objectAtIndex:theRow];
    NSString *aDomainName = nil;
    NSString *anImageDomainName = [aDomain valueForKey:@"name"];
    NSString *aLocalizedLanguage = [Session language];
    if ([aLocalizedLanguage isEqualToString:@"en"] ) {
        aDomainName = [aDomain valueForKey:@"name"];
    } else if ([aLocalizedLanguage isEqualToString:@"es"]){
        aDomainName = [aDomain valueForKey:@"name_es"];
    }
    
    aCell.imageView.image = IMAGE(anImageDomainName);
    aCell.textLabel.text = aDomainName;
    return aCell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)iTableView didSelectRowAtIndexPath:(NSIndexPath *)iIndexPath {
    [iTableView deselectRowAtIndexPath:iIndexPath animated:YES];
    
    NSInteger theRow = iIndexPath.row;
    NSDictionary *aDomain = [[[Session content] valueForKey:@"domain"] objectAtIndex:theRow];
    NSString *aDomainID = [aDomain valueForKey:@"id"];
    
    [Session setSelections:[NSMutableDictionary dictionary]];
    NSString *aLocalizedLanguage = [Session language];
    if ([aLocalizedLanguage isEqualToString:@"en"] ) {
        [[Session selections] setObject:[aDomain valueForKey:@"name"] forKey:@"Area"];
    } else if ([aLocalizedLanguage isEqualToString:@"es"]){
        [[Session selections] setObject:[aDomain valueForKey:@"name_es"] forKey:@"Area"];
    }

    
    
    
//    [[Session selections] setObject:[aDomain valueForKey:@"name"] forKey:@"Area"];
    IPSProblemView *aProblemView = [[IPSProblemView alloc] initWithDomain:aDomainID];
    [AppDelegate.window addSubview:aProblemView];
}


- (CGFloat)tableView:(UITableView *)iTableView heightForRowAtIndexPath:(NSIndexPath *)iIndexPath {
    CGFloat aHeight = 50;
    return aHeight;
}


#pragma mark - Private

- (void)showTips {
    [[[UIAlertView alloc] initWithTitle:nil message:STLocalizedString(@"IPSProblemController_ShowTips", @"") delegate:nil cancelButtonTitle:STLocalizedString(@"OkButtonTitle", @"") otherButtonTitles:nil] show];
}


#pragma mark - Memory Mgmt

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@end
