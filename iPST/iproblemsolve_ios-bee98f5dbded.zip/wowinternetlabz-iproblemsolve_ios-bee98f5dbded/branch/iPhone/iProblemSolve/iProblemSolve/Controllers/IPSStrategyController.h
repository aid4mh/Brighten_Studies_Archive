//
//  IPSStrategyController.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 12/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface IPSStrategyController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) NSString *problemID;
@property (nonatomic, retain) NSString *domainID;

- (id)initWithGoal:(NSString *)iGoalID;

@end
