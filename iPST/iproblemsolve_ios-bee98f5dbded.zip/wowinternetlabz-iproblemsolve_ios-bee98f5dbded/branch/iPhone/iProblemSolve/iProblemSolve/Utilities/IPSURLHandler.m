//
//  IPSURLHandler.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 06/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSURLHandler.h"


@interface IPSURLHandler ()

@property (nonatomic, retain) NSString *urlString;
@property (nonatomic, retain) NSMutableData *responseData;
@property (nonatomic, retain) NSURLConnection *urlConnection;

@end


@implementation IPSURLHandler

@synthesize tag;
@synthesize delegate;
@synthesize urlString;
@synthesize responseData;
@synthesize urlConnection;

#pragma mark - Initialization Method

- (id)initWithURLString:(NSString *)iURLString {
    if (self = [super init]) {
		self.urlString = iURLString;
	}
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
	self.urlConnection = nil;
    self.responseData = nil;
	self.urlString = nil;
}


#pragma mark - Public Methods

- (NSData *)getResponseDataWithError:(NSError **)iError {
    NSURL *anURL = [NSURL URLWithString:self.urlString];
	NSURLRequest *anURLRequest=[NSURLRequest requestWithURL:anURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    NSURLResponse *anURLResponse;
    NSData *aResponseData = [NSURLConnection sendSynchronousRequest:anURLRequest returningResponse:&anURLResponse error:iError];
    return aResponseData;
}


- (NSData *)getResponseData {
    NSError *anError;
    NSData *aResponseData = [self getResponseDataWithError:&anError];
    return aResponseData;
}


- (void)sendRequest {
    NSURL *anURL = [NSURL URLWithString:self.urlString];
    NSLog(@"anURL: %@", anURL);
    
	NSURLRequest *anURLRequest=[NSURLRequest requestWithURL:anURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    self.responseData = [[NSMutableData alloc] init];
	self.urlConnection =[[NSURLConnection alloc] initWithRequest:anURLRequest delegate:self startImmediately:YES];
}


- (void)sendRequestWithPost:(NSDictionary *)iPost {
    NSMutableString *aPostBody = [NSMutableString string];
    for (NSString *aKey in [iPost allKeys]) {
        NSString *aString = [NSString stringWithFormat:@"%@=%@&", aKey, [iPost valueForKey:aKey]];
        [aPostBody appendString:aString];
    }
    
    if ([aPostBody hasSuffix:@"&"]) {
        [aPostBody deleteCharactersInRange:NSMakeRange((aPostBody.length - 1), 1)];
    }
    
    NSLog(@"POST: %@", aPostBody);
    
    [self sendRequestWithPostBody:aPostBody];
}


- (void)sendRequestWithPostBody:(NSString *)iPostBody {
    NSURL *anURL = [NSURL URLWithString:self.urlString];
	NSMutableURLRequest *anURLRequest=[NSMutableURLRequest requestWithURL:anURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    [anURLRequest setHTTPMethod:@"POST"];
    [anURLRequest setHTTPBody:[iPostBody dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.responseData = [[NSMutableData alloc] init];
	self.urlConnection =[[NSURLConnection alloc] initWithRequest:anURLRequest delegate:self startImmediately:YES];
}


- (NSData *)getResponseForPostBody:(NSString *)iPostBody {
    NSError *anError = nil;
    NSURL *anURL = [NSURL URLWithString:self.urlString];
    
	NSMutableURLRequest *anURLRequest=[NSMutableURLRequest requestWithURL:anURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    [anURLRequest setHTTPMethod:@"POST"];
    [anURLRequest setHTTPBody:[iPostBody dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLResponse *anURLResponse;
    NSData *aResponseData = [NSURLConnection sendSynchronousRequest:anURLRequest returningResponse:&anURLResponse error:&anError];
    return aResponseData;
}


- (NSData *)getResponseForPostBody:(NSString *)iPostBody withResponse:(NSURLResponse **)iURLResponse {
    NSError *anError = nil;
    NSURL *anURL = [NSURL URLWithString:self.urlString];
    
	NSMutableURLRequest *anURLRequest=[NSMutableURLRequest requestWithURL:anURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    [anURLRequest setHTTPMethod:@"POST"];
    [anURLRequest setHTTPBody:[iPostBody dataUsingEncoding:NSUTF8StringEncoding]];
    
    [anURLRequest setValue:@"mobile" forHTTPHeaderField:@"X-Auth-Username"];
    [anURLRequest setValue:@"GuxbcYSh1A6gd1oCJWJDpbUwxRRV@9Of" forHTTPHeaderField:@"X-Auth-Key"];
    
    NSData *aResponseData = [NSURLConnection sendSynchronousRequest:anURLRequest returningResponse:iURLResponse error:&anError];
    return aResponseData;
}


#pragma mark - NSURLConnectionDelegate Methods

- (void)connection:(NSURLConnection *)iConnection didReceiveData:(NSData *)iData {
	[self.responseData appendData: iData];
}


- (void)connectionDidFinishLoading:(NSURLConnection *)iConnection {
  NSLog(@"Recieving Response");
    if (self.delegate) {
        id aJSONValue = [self.responseData JSONValue];
        if (aJSONValue) {
            if (self.delegate && [self.delegate respondsToSelector:@selector(urlHandler:didFinishLoadingWithResponse:)]) {
                [self.delegate urlHandler:self didFinishLoadingWithResponse:aJSONValue];
            }
        } else {
            NSString *aResponseString = [[NSString alloc] initWithData:self.responseData encoding:NSUTF8StringEncoding];
            if (self.delegate && [self.delegate respondsToSelector:@selector(urlHandler:didFinishLoadingWithResponse:)]) {
                [self.delegate urlHandler:self didFinishLoadingWithResponse:aResponseString];
            }
        }
    }
}


- (void)connection:(NSURLConnection *)iConnection didFailWithError:(NSError *)iError {
    if (self.delegate && [self.delegate respondsToSelector:@selector(urlHandler:didFailToLoadWithError:)]) {
        [self.delegate urlHandler:self didFailToLoadWithError:iError];
    }
}


@end