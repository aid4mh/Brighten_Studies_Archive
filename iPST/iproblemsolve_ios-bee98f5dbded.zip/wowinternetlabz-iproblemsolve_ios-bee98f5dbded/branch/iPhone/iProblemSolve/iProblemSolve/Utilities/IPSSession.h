//
//  IPSSession.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 06/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSURLHandler.h"
#import <Foundation/Foundation.h>


typedef enum {
    CONTENT_STATUS_COMPLETE,
    CONTENT_STATUS_LOADING,
    CONTENT_STATUS_FAILED
} CONTENT_STATUS;


@interface IPSSession : NSObject <IPSURLDelegate>

#pragma mark - Variables

@property (nonatomic, retain) NSMutableDictionary *selections;
@property (nonatomic, retain) NSMutableArray *userActivity;
@property (nonatomic, retain) NSMutableDictionary *content;
@property (nonatomic, assign) CONTENT_STATUS contentStatus;
@property (nonatomic, retain) NSMutableArray *actionPlans;
@property (nonatomic, retain) NSMutableArray *moods;
@property (nonatomic, retain) NSString *language;
@property (nonatomic, retain) NSString *userID;


#pragma mark - Methods

- (void)loadMood;
- (void)loadAppContent;
- (void)loadActionPlan;
- (BOOL)shouldCheckMood;
- (void)updateActionPlan;
- (NSString *)UTCDateString;
- (void)updateMood:(NSInteger)iMood;
- (NSString *)UTCDateStringForDate:(NSDate *)iDate;


#pragma mark - Singleton

+ (IPSSession *)sharedIPSSession;

@end
