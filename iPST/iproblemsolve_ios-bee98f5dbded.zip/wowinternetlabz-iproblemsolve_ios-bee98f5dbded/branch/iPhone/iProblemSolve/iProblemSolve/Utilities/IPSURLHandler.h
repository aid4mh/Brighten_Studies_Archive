//
//  IPSURLHandler.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 06/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol IPSURLDelegate;


@interface IPSURLHandler : NSObject

// Properties
@property (nonatomic, assign) NSInteger tag;
@property (nonatomic, assign) id<IPSURLDelegate> delegate;

// Intitalization
- (id)initWithURLString:(NSString *)iURLString;

// Public Methods
- (void)sendRequest;
- (NSData *)getResponseData;
- (void)sendRequestWithPost:(NSDictionary *)iPost;
- (void)sendRequestWithPostBody:(NSString *)iPostBody;
- (NSData *)getResponseDataWithError:(NSError **)iError;
- (NSData *)getResponseForPostBody:(NSString *)iPostBody;
- (NSData *)getResponseForPostBody:(NSString *)iPostBody withResponse:(NSURLResponse **)iURLResponse;

@end


@protocol IPSURLDelegate <NSObject>

- (void)urlHandler:(IPSURLHandler *)iHandler didFinishLoadingWithResponse:(id)iResponse;
- (void)urlHandler:(IPSURLHandler *)iHandler didFailToLoadWithError:(NSError *)iError;

@end