//
//  IPSLoadingView.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 22/02/14.
//  Copyright (c) 2014 Wow Labz. All rights reserved.
//

#import "IPSLoadingView.h"


@interface IPSLoadingView ()

@property (nonatomic, retain) NSString *message;
@property (nonatomic, assign) BOOL showProgress;

@end


@implementation IPSLoadingView

@synthesize message;
@synthesize progressView;
@synthesize showProgress;
@synthesize isSplashScreen;

#pragma mark - Initialization Method

- (id)initWithFrame:(CGRect)iFrame message:(NSString *)iMessage showProgress:(BOOL)iShowProgress {
    if (self = [super initWithFrame:iFrame]) {
		self.message = iMessage;
		self.showProgress = iShowProgress;
        if (iShowProgress) {
            self.progressView = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleBar];
        }
    }
    return self;
}


#pragma mark - Destruction

- (void)dealloc {
	self.message = nil;
	self.progressView = nil;
}


#pragma mark - LayoutSubviews

- (void)layoutSubviews {
	[super layoutSubviews];
	
    if (self.isSplashScreen) {
        UIImage* aBackgroundImage;
        CGFloat aScreenHeight = [UIScreen mainScreen].bounds.size.height;
        if ([UIScreen mainScreen].scale == 2.f && aScreenHeight == 568.0f) {
            aBackgroundImage = [UIImage imageNamed:@"Default-568h@2x.png"];
        } else {
            aBackgroundImage = [UIImage imageNamed:@"Default"];
        }
        
        UIImageView *aBackgroundView = [[UIImageView alloc] initWithImage:aBackgroundImage];
        aBackgroundView.frame = self.bounds;
        
        UIActivityIndicatorView *anActivityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
        [anActivityIndicator startAnimating];
        anActivityIndicator.center = self.center;
        [aBackgroundView addSubview:anActivityIndicator];
        
        [self addSubview:aBackgroundView];
    } else {
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.6];
        
        if (self.showProgress) {
            self.progressView = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleBar];
            self.progressView.center = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
            [self addSubview:self.progressView];
        } else {
            UIActivityIndicatorView *anActivityIndicator;
            if (self.bounds.size.height > 50) {
                anActivityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
            } else {
                anActivityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
            }
            
            [anActivityIndicator sizeToFit];
            [anActivityIndicator startAnimating];
            anActivityIndicator.center = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
            [self addSubview:anActivityIndicator];
        }
        
        if (self.message) {
            CGRect aFrame;
            aFrame.origin.x = 0;
            aFrame.size.height = 40;
            aFrame.size.width = self.bounds.size.width;
            aFrame.origin.y = CGRectGetMidY(self.bounds) + 10;
            
            UILabel *aLabel = [[UILabel alloc] initWithFrame:aFrame];
            aLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:20];
            aLabel.backgroundColor = [UIColor clearColor];
            aLabel.textAlignment = NSTextAlignmentCenter;
            aLabel.shadowColor = [UIColor grayColor];
            aLabel.textColor = [UIColor whiteColor];
            aLabel.text = self.message;
            [self addSubview:aLabel];
        }
    }
}

@end
