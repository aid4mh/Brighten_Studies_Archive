//
//  IPSProblemView.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 09/12/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface IPSProblemView : UIView <UITableViewDataSource, UITableViewDelegate>

- (id)initWithDomain:(NSString *)iDomainID;

@end
