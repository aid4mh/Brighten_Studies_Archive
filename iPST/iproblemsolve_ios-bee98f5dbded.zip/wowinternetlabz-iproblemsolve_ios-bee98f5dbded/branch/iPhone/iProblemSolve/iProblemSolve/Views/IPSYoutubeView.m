//
//  IPSYoutubeView.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 22/02/14.
//  Copyright (c) 2014 Wow Labz. All rights reserved.
//

#import "IPSYoutubeView.h"

@implementation IPSYoutubeView

#pragma mark - Initialization

- (id)initWithFrame:(CGRect)iFrame url:(NSString *)iURL {
    self = [super initWithFrame:iFrame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        NSString *aMobileURL = @"m.youtube.com";
        NSString *aWebURL = @"www.youtube.com";
        iURL = [iURL stringByReplacingOccurrencesOfString:aMobileURL withString:aWebURL];
        
        NSString *aYoutubeID;
        if ([iURL rangeOfString:@"youtu.be/"].length > 0) {
            aYoutubeID = [[iURL componentsSeparatedByString:@"/"] lastObject];
        } else {
            aYoutubeID = [[iURL componentsSeparatedByString:@"v="] objectAtIndex:1];
        }
        
        
        //NSString *aYoutubeID = [[iURL componentsSeparatedByString:@"v="] objectAtIndex:1];
        aYoutubeID = [[aYoutubeID componentsSeparatedByString:@"&"] objectAtIndex:0];
        
        // Populate HTML with the URL and requested frame size
        NSString *aHTMLSting = [NSString stringWithFormat:@"\
                                <html><head>\
                                <style type=\"text/css\">\
                                body {\
                                background-color: transparent;\
                                color: blue;\
                                }\
                                </style>\
                                </head><body style=\"margin:0\">\
                                <iframe height=\"%0.0f\" width=\"320\" frameborder=\"0\" src=\"http://www.youtube.com/embed/%@?title=&loop=1&showinfo=0\"></iframe>\
                                </body></html>", iFrame.size.height, aYoutubeID];
        
        
        // Load the html into the webview
        [self loadHTMLString:aHTMLSting baseURL:nil];
        
        // Disable Scroll
        [(UIScrollView *)[self.subviews objectAtIndex:0] setScrollEnabled:NO];
        
        self.delegate = self;
        
    }
    return self;
}


#pragma mark - UIWebViewDelegate

- (BOOL)webView:(UIWebView *)iWebView shouldStartLoadWithRequest:(NSURLRequest *)iRequest
 navigationType:(UIWebViewNavigationType)iNavigationType {
    if ([iRequest.URL.absoluteString hasSuffix:@"feature=player_embedded"]) {
        return NO;
    }
    
    return YES;
}

@end
