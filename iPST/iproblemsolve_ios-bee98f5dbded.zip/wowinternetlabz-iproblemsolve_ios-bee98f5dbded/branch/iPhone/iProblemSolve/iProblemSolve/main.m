//
//  main.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 25/11/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "IPSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([IPSAppDelegate class]));
    }
}
