//
//  IPSConstant.h
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 25/11/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#pragma mark - Macros

//#define ADMIN_USERNAME  @"GREEN-00005"
//
//#define ADMIN_PASSWORD  @"S77IvT"

#define IS_IPHONE5          (UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPhone && [UIScreen mainScreen].bounds.size.height==568)

#define IS_iOS7             (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1)

#define IS_iOS6             (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_5_1)

#define IS_RETINA           ([UIScreen mainScreen].scale == 2.0)

#define BACKGROUND_IMAGE    ((IS_IPHONE5)? [UIImage imageNamed:@"Background"] : [UIImage imageNamed:@"Background.png"])

#define LANDSCAPE_IMAGE     ((IS_IPHONE5)? [UIImage imageNamed:@"Landscape"] : [UIImage imageNamed:@"Landscape.png"])

#define DEFAULT_IMAGE       ((IS_IPHONE5)? [UIImage imageNamed:@"Default"] : [UIImage imageNamed:@"Default.png"])

#define RGBA_COLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

#define FONT(kName, kSize)  [UIFont fontWithName:kName size:kSize]

#define IMAGE(kName)        [UIImage imageNamed:kName]

#define SCREEN_HEIGHT       [UIScreen mainScreen].bounds.size.height

#define SCREEN_WIDTH        [UIScreen mainScreen].bounds.size.width

#define NAVIGATION_COLOR    RGBA_COLOR(251, 230, 145, 1)

#define HELVETICA_NEUE(kSize)   FONT(@"HelveticaNeue", kSize)

#define IMAGE_5(kName, kImage) {\
if (IS_IPHONE5) {\
NSString *anImageName = [kName stringByReplacingOccurrencesOfString:@".png" withString:@"-568h@2x.png"];\
*kImage = [UIImage imageNamed:anImageName];\
} else {\
*kImage = [UIImage imageNamed:kName];\
}\
}\

#define SET_BACKGROUND(kView, kFrame)     {\
UIImageView *aView = [[UIImageView alloc] initWithImage:BACKGROUND_IMAGE];\
aView.frame = kFrame;\
[kView addSubview:aView];\
[kView sendSubviewToBack:aView];\
}

#define SET_LANDSCAPE(kView, kFrame)     {\
UIImageView *aView = [[UIImageView alloc] initWithImage:LANDSCAPE_IMAGE];\
aView.frame = kFrame;\
[kView addSubview:aView];\
[kView sendSubviewToBack:aView];\
}

#define BORDER(kView) {\
kView.layer.borderColor = [[UIColor redColor] CGColor];\
kView.layer.borderWidth = 2;\
}\

#define BORDER_VALUES(kView, kColor, kWidth) {\
kView.layer.borderColor = [kColor CGColor];\
kView.layer.borderWidth = kWidth;\
}\


#pragma mark - CONSTANTS

#define USER_ACTIVITY   @"USER_ACTIVITY"
#define CONTENT_DATE    @"CONTENT_DATE"
#define USER_ID         @"USER_ID"


#pragma mark - NOTIFICATION

#define CHECK_ACTION_PLAN   @"CHECK_ACTION_PLAN"
#define SUCCESSFUL_LOGIN    @"SUCCESSFUL_LOGIN"


#pragma mark - URL

#define BASE_URL        @"http://wowlabz.com/projects/iProblemSolve/index.php/api/"
#define GET_DUMP_API    @"getDump"

