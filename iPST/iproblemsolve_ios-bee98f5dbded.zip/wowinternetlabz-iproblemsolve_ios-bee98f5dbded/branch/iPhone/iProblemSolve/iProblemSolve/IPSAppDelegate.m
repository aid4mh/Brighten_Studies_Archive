//
//  IPSAppDelegate.m
//  iProblemSolve
//
//  Created by Roshit Omanakuttan on 25/11/13.
//  Copyright (c) 2013 Wow Labz. All rights reserved.
//


#import "IPSPlannedActionController.h"
#import "IPSHomeController.h"
#import "IPSProblemView.h"
#import "IPSAppDelegate.h"
#import "IPSLoginView.h"
#import "IPSMoodView.h"


#define SPLASH_DURATION 3


@implementation IPSAppDelegate

#pragma mark - UIApplicationDelegate

- (BOOL)application:(UIApplication *)iApplication didFinishLaunchingWithOptions:(NSDictionary *)iLaunchOptions {
    if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
        [[UINavigationBar appearance] setBarTintColor:NAVIGATION_COLOR];
        [[UINavigationBar appearance] setTintColor:[UIColor blackColor]];
    } else {
        [[UINavigationBar appearance] setTintColor:NAVIGATION_COLOR];
    }
    //NSShadow *shadow = [NSShadow new];
    //[shadow setShadowColor: [UIColor colorWithWhite:0.0f alpha:0.750f]];
   // [shadow setShadowOffset: CGSizeMake(0.0f, 1.0f)];
    
    NSDictionary *aTextAttribute = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [UIColor blackColor],NSForegroundColorAttributeName,
                                    [UIColor whiteColor], UITextAttributeTextShadowColor,
                                    [NSValue valueWithUIOffset:UIOffsetMake(0, 0.5)], UITextAttributeTextShadowOffset, nil];
    
    UIBarItem *aBarButtonItem = [UIBarButtonItem appearanceWhenContainedIn:[UINavigationBar class], nil];
    [aBarButtonItem setTitleTextAttributes:aTextAttribute forState: UIControlStateNormal];
    
    [[UINavigationBar appearance] setTitleTextAttributes:aTextAttribute];
    
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerForRemoteNotifications)]) {
        UIUserNotificationSettings *anUserSettings = [UIUserNotificationSettings settingsForTypes:
                                                      UIUserNotificationTypeAlert | UIUserNotificationTypeBadge |
                                                      UIUserNotificationTypeSound categories:nil];
        
        [[UIApplication sharedApplication] registerUserNotificationSettings:anUserSettings];
    } else {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    }
    
    [[UIApplication sharedApplication] setMinimumBackgroundFetchInterval:UIApplicationBackgroundFetchIntervalMinimum];
    
    
    NSUserDefaults *anUserDefault = [NSUserDefaults standardUserDefaults];
    if ([anUserDefault valueForKey:USER_ID] && ([[anUserDefault valueForKey:USER_ID] length] > 0)) {
        [Session setUserID:[anUserDefault valueForKey:USER_ID]];
    } else {
        [Session setUserID:nil];
    }
    
    if ([anUserDefault valueForKey:USER_ACTIVITY]) {
        [Session setUserActivity:[NSMutableArray arrayWithArray:[anUserDefault valueForKey:USER_ACTIVITY]]];
    } else {
        [Session setUserActivity:[NSMutableArray array]];
    }
    
    [self showSplashScreen];
    
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)iApplication {
}


- (void)applicationDidEnterBackground:(UIApplication *)iApplication {
}


- (void)applicationWillEnterForeground:(UIApplication *)iApplication {
    NSUserDefaults *anUserDefault = [NSUserDefaults standardUserDefaults];
    if ([anUserDefault valueForKey:USER_ID] && ([[anUserDefault valueForKey:USER_ID] length] > 0)) {
        [Session setUserID:[anUserDefault valueForKey:USER_ID]];
    } else {
        [Session setUserID:nil];
    }
    
    if ([anUserDefault valueForKey:USER_ACTIVITY]) {
        [Session setUserActivity:[NSMutableArray arrayWithArray:[anUserDefault valueForKey:USER_ACTIVITY]]];
    } else {
        [Session setUserActivity:[NSMutableArray array]];
    }
    
    [self showSplashScreen];
}


- (void)applicationDidBecomeActive:(UIApplication *)iApplication {
}


- (void)applicationWillTerminate:(UIApplication *)iApplication {
}


- (void)application:(UIApplication *)iApplication didRegisterUserNotificationSettings:(UIUserNotificationSettings *)iNotificationSettings {
    [[UIApplication sharedApplication] registerForRemoteNotifications];
}


- (void)application:(UIApplication*)iApplication didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)iDeviceToken {
    const char *aTokenBytes = [iDeviceToken bytes];
    NSMutableString *aDeviceToken = [NSMutableString string];
    for (int anIndex = 0; anIndex < [iDeviceToken length]; anIndex++) {
        [aDeviceToken appendFormat:@"%02.2hhX", aTokenBytes[anIndex]];
    }
}


- (void)application:(UIApplication*)iApplication didFailToRegisterForRemoteNotificationsWithError:(NSError*)iError {
}


- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
    NSLog(@"BG: didReceiveLocalNotification");
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler {
    NSLog(@"BG: didReceiveRemoteNotification");
    
    completionHandler(UIBackgroundFetchResultNewData);
}


- (void)application:(UIApplication *)application performFetchWithCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler {
    NSLog(@"BG: performFetchWithCompletionHandler");
    
    completionHandler(UIBackgroundFetchResultNewData);
}


#pragma mark - Private

- (void)showSplashScreen {
    [self loadContent];
    [Session loadMood];
    [Session loadActionPlan];
    
    UIImage *anImage = nil;
    IMAGE_5(@"LaunchImage.png", &anImage);
    
    UIImageView *aDefaultView = [[UIImageView alloc] initWithImage:anImage];
    [AppDelegate.window.rootViewController.view addSubview:aDefaultView];
    aDefaultView.frame = AppDelegate.window.frame;
    
    UIImageView *aSunView = [[UIImageView alloc] initWithImage:IMAGE(@"Sun")];
    aSunView.frame = CGRectMake(0, 0, 190, 190);
    aSunView.center = aDefaultView.center;
    [aDefaultView addSubview:aSunView];
    
    CGRect aFrame = aSunView.frame;
    aFrame.origin.y += 50;
    
    aSunView.frame = aFrame;
    aSunView.alpha = 0.5;
    
    [UIView animateWithDuration:SPLASH_DURATION animations:^{
        CGRect aFrame = aSunView.frame;
        aFrame.origin.y -= 100;
        
        aSunView.frame = aFrame;
        aSunView.alpha = 1.0;
    } completion:^(BOOL finished) {
        [self removeDefaultScreen:aDefaultView];
    }];
}


- (void)removeDefaultScreen:(UIImageView *)iScreen {
    [iScreen removeFromSuperview];
    
    if ([Session userID]) {
        [self checkMood];
    } else {
        [self loadLogin];
    }
}


- (void)checkMood {
    if ([Session shouldCheckMood]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkActionPlan) name:CHECK_ACTION_PLAN object:nil];
        IPSMoodView *aMoodView = [[IPSMoodView alloc] init];
        [self.window addSubview:aMoodView];
    }
}


- (void)loadLogin {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(successfulLogin:) name:SUCCESSFUL_LOGIN object:nil];
    IPSLoginView *aLoginView = [[IPSLoginView alloc] init];
    [self.window addSubview:aLoginView];
    [aLoginView checkLanguage];
}


- (void)successfulLogin:(NSNotification *)iNotification {
    if ([[iNotification object] isKindOfClass:[IPSLoginView class]]) {
        [(IPSLoginView *)[iNotification object] removeFromSuperview];
    }
    
    UIViewController *aController = [(UINavigationController *)[[((IPSAppDelegate *)[UIApplication sharedApplication].delegate) window] rootViewController] topViewController];
    if ([aController isKindOfClass:[IPSHomeController class]]) {
        [(IPSHomeController *)aController reloadScreen];
    }
    
    [self checkMood];
}


- (void)loadContent {
    BOOL shouldLoadContent = YES;
    
    NSUserDefaults *anUserDefault = [NSUserDefaults standardUserDefaults];
    if ([anUserDefault valueForKey:CONTENT_DATE]) {
        NSDateFormatter *aDateFormat = [[NSDateFormatter alloc] init];
        [aDateFormat setDateFormat:@"dd-MM-yyyy"];
        NSString *aTodaysDate = [aDateFormat stringFromDate:[NSDate date]];
        NSString *aContentDate = [anUserDefault valueForKey:CONTENT_DATE];
        if ([aContentDate isEqualToString:aTodaysDate]) {
            shouldLoadContent = NO;
        }
    }
    
    if (shouldLoadContent) {
        [Session loadAppContent];
    } else {
        if (![Session content]) {
            NSString *aPath  = [NSString stringWithFormat:@"%@/Content.plist", ApplicationSupport];
            if ([[NSFileManager defaultManager] fileExistsAtPath:aPath isDirectory:NO]) {
                [Session setContent:[NSMutableDictionary dictionaryWithContentsOfFile:aPath]];
            } else {
                [Session loadAppContent];
            }
        }
    }
}


- (void)checkActionPlan {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:CHECK_ACTION_PLAN object:nil];
    
    if ([[Session actionPlans] count] > 0) {
        if ([[self window] subviews]) {
            for (UIView *aView in [[self window] subviews]) {
                if ([aView isKindOfClass:[IPSProblemView class]]) {
                    [aView removeFromSuperview];
                }
            }
        }
    UIAlertView *anAlertView = [[UIAlertView alloc] initWithTitle:STLocalizedString(@"ActionPlans", @"") message:STLocalizedString(@"ActionPlanReviewMsg", @"") delegate:self cancelButtonTitle:STLocalizedString(@"CancelButtonTitle", @"") otherButtonTitles:STLocalizedString(@"ViewActionPlan", @""), nil];
        [anAlertView show];
    }
}


#pragma mark - UIAlertViewDelegate 

- (void)alertView:(UIAlertView *)iAlertView clickedButtonAtIndex:(NSInteger)iButtonIndex {
    if (iButtonIndex == 1) {
        UINavigationController *aNavigation = (UINavigationController *)self.window.rootViewController;
        [aNavigation popToRootViewControllerAnimated:NO];
        
        IPSPlannedActionController *aPlannedActionController = [[IPSPlannedActionController alloc] init];
        [aNavigation pushViewController:aPlannedActionController animated:YES];
    }
}

@end
